#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"

using namespace std;

class Student;
class Admin;
class Lecturer;
class Subject;
class ClassTiming;

class Student
{
private:
	string firstName;
	string lastName;
	int studentId;
	string password;
	string email;
	string address;
	int contactNum;
	vector <Subject> subjectList;

public:

static int studentKey;

Student()
{
	firstName = "";
	lastName = "";
	studentId = 0;
	password = "";
	email = "";
	address = "";
	contactNum = 0;
}

Student(string fName, string lName, string p, string e, string add, int contNum)
{
	firstName = fName;
	lastName = lName;
	password = p;
	email = e;
	address = add;
	contactNum = contNum;
	studentKey++;
	studentId = studentKey;
}

Student(int studId, string fName, string lName, string p, string e, string add, int contNum)
{
    studentId = studId;
	firstName = fName;
	lastName = lName;
	password = p;
	email = e;
	address = add;
	contactNum = contNum;
	studentKey++;
}

	void setPassword(string);
	void setEmail(string);
	void setAddress(string);
	void setContactNum(int);
	void setSubjectList(Subject&);

	string getFirstName();
	string getLastName();
	int getStudentId();
	string getPassword();
	string getEmail();
	string getAddress();
	int getContactNum();
	vector <Subject> getSubjectList();

	void editProfile(MYSQL* conn);

	void enrollSubject(map<int, Subject>&, map<int, Student>&);
	void addSubject(map<int, Subject>&, map<int,Student>&);
	void removeSubject(map<int, Subject>&, map<int,Student>& );

	void viewRegisteredSubject();
	void viewLearningMaterials(map<int,Subject>& );
	void viewAttendance(map<int,Subject>&);
	void viewTestResult(map<int,Subject>&);
	void viewCourseWork(map<int,Subject>&);
	void viewClassSchedule();
	void viewLecturerDetails();

	void homeDisplay();
	void profileDisplay();
	void display();

};

int Student::studentKey = 18000;


class Lecturer
{
private:
	string firstName;
	string lastName;
	int lecturerId;
	string password;
	string email;
	string address;
	int contactNum;
	vector <Subject> assignedSubjects;

public:

	static int lecturerKey;

Lecturer()
{
	firstName="";
	lastName="";
	password="";
	email="";
	address="";
	contactNum=0;
	lecturerId=0;
}

Lecturer(string fName, string lName, string p, string e, string add, int contNum)
{
	firstName=fName;
	lastName=lName;
	password=p;
	email=e;
	address=add;
	contactNum=contNum;
	lecturerKey++;
	lecturerId=lecturerKey;
}


Lecturer(int lecId, string fName, string lName, string p, string e, string add, int contNum)
{
    lecturerId = lecId;
	firstName = fName;
	lastName = lName;
	password = p;
	email = e;
	address = add;
	contactNum = contNum;
	lecturerKey++;
}


	void setPassword(string);
	void setEmail(string);
	void setAddress(string);
	void setContactNum(int);
	void setAssignedSubjects(Subject&);

	string getFirstName();
	string getLastName();
	int getlecturerId();
	string getPassword();
	string getEmail();
	string getAddress();
	int getContactNum();
	vector <Subject> getAssignedSubjects();

	void editProfile(MYSQL* conn);

	void viewSubjectList();
	void viewStudentList(map<int,Subject>&);
	void updateLearningMaterials(map<int,Subject>&);
	void updateAttendance(map<int,Subject>&);
	void updateTestResult(map<int,Subject>&);
	void updateCourseWork(map<int,Subject>&);

	void display();
	void profileDisplay();
	void homeDisplay();

};

int Lecturer::lecturerKey=12000;



class ClassTiming
{
private:
    int timingId;
	string time;
	string day;
	string ClassRoomNumber;
public:
	static int timingKey;

ClassTiming()
 {
	timingId = 0;
	time = "";
	day = "";
	ClassRoomNumber = "";
 }

ClassTiming(string tM, string Day, string classRoomNumber)
 {
	time = tM;
	day = Day;
	ClassRoomNumber = classRoomNumber;
	timingKey++;
	timingId = timingKey;
 }

    void setTimingId(int);
	void setTime(string);
	void setDay(string);
	void setClassroomNumber(string);

	int getTimingId();
	string getTime();
	string getDay();
	string getClassroomNumber();


	void display();

};

int ClassTiming::timingKey=30000;



class Subject
{
private:
	int subjectCode;
	string subjectName;
	int creditHour;
	int trimesterWeeks;
	vector <ClassTiming> classTime;
	Lecturer lecturer;
	multimap <int, string> learningMaterials;
	vector <Student> studentList;
	map<int, double> testResult;
	map<int, double> courseWork;
	map<int, double> attendance;

public:

	static int subjectKey;
Subject()
{

}

Subject(string subName, int cdtHr, int triWeeks)
{
	subjectName=subName;
	creditHour=cdtHr;
	trimesterWeeks=triWeeks;
	subjectKey++;
	subjectCode=subjectKey;
}

Subject(int subCode, string subName, int cdtHr, int triWeeks)
{
	subjectCode=subCode;
	subjectName=subName;
	creditHour=cdtHr;
	trimesterWeeks=triWeeks;
	subjectKey++;
}

	void setSubjectName(string);
	void setCreditHour(int);
	void setTrimesterWweeks(int);
	void setClassTiming(ClassTiming&);
	void setLecturer(Lecturer&);
	void setStudentList(Student&);
	void removeStudent(Student&);
	void setLearningmaterials(int, string);
	void setTestResult(int, double);
	void setCourseWork(int, double);
	void setAttendance(int, double);

	int getsubjectCode();
	string getSubjectName();
	int getCreditHour();
	int getTrimesterWeeks();
	vector<ClassTiming> getClassTiming();
	Lecturer getLecturer();
	multimap <int, string> getLearningmaterials();
	vector <Student> getStudentList();
	map <int, double> getTestResult();
	map <int, double> getCourseWork();
	map <int, double> getAttendance();

	void display();

};

int Subject::subjectKey=8000;

void Subject::setSubjectName(string subName)
{
	subjectName=subName;
}

void Subject::setCreditHour(int cdtHr)
{
	creditHour=cdtHr;
}


void Subject::setTrimesterWweeks(int triWeeks)
{
	trimesterWeeks=triWeeks;
}


void Subject::setClassTiming(ClassTiming& ct)
{

		classTime.push_back(ct);
}


void Subject::setLecturer(Lecturer& lec)
{
	lecturer=lec;
}


void Subject::setStudentList(Student& s)
{
	int count=0;
	for(int i=0;i<studentList.size();i++)
	{
		if(s.getStudentId()!=studentList[i].getStudentId())
		{
			count++;
		}
	}
	if(count==studentList.size())
	{
		studentList.push_back(s);
	}
}

void Subject::removeStudent(Student& s)
{
	for(int i=0; i<studentList.size(); i++)
	{
		if(s.getStudentId()==studentList[i].getStudentId())
		{
			studentList.erase(studentList.begin()+i);
		}
	}
}

void Subject::setLearningmaterials(int index, string materials)
{
	learningMaterials.insert({index,materials});
}

void Subject::setTestResult(int sID, double testScore)
{
	testResult[sID]=testScore;
}


void Subject::setCourseWork(int sID, double courseMark)
{
	courseWork[sID]=courseMark;
}


void Subject::setAttendance(int sID, double att)
{
	attendance[sID]=att;
}



int Subject::getsubjectCode()
{
	return subjectCode;
}


string Subject::getSubjectName()
{
	return subjectName;
}


int Subject::getCreditHour()
{
	return creditHour;
}


int Subject::getTrimesterWeeks()
{
	return trimesterWeeks;
}


vector<ClassTiming> Subject::getClassTiming()
{
	return classTime;
}


Lecturer Subject::getLecturer()
{
	return lecturer;
}


multimap <int, string> Subject::getLearningmaterials()
{
	return learningMaterials;
}


vector <Student> Subject::getStudentList()
{
	return studentList;
}


map <int, double> Subject::getTestResult()
{
	return testResult;
}


map <int, double> Subject::getCourseWork()
{
	return courseWork;
}


map <int, double> Subject::getAttendance()
{
	return attendance;
}

void Subject::display()
{
	cout<<endl;
	cout<<"Subject Name: "<<subjectName<<endl;
	cout<<"Subject Code: "<<subjectCode<<endl;
	cout<<"Credit Hour: "<<creditHour<<endl;
	cout<<"Trimester Length: "<<trimesterWeeks<<endl;
	cout<<"---------------------------------------------------------"<<endl;

}



class Admin
{
private:
	string firstName;
	string lastName;
	int adminId;
	string password;
	string email;
	string address;
	int contactNum;

public:

	static int adminKey;

Admin()
{
	firstName="";
	lastName="";
	password="";
	email="";
	address="";
	contactNum=0;
	adminId=0;
}

Admin(string fName, string lName, string p, string e, string add, int contNum)
{
	firstName=fName;
	lastName=lName;
	password=p;
	email=e;
	address=add;
	contactNum=contNum;
	adminKey++;
	adminId=adminKey;
}

Admin(int aId, string fName, string lName, string p, string e, string add, int contNum)
{
	adminId=aId;
	firstName=fName;
	lastName=lName;
	password=p;
	email=e;
	address=add;
	contactNum=contNum;
	adminKey++;
}

	void setFirstName(string);
	void setLastName(string);
	void setPassword(string);
	void setEmail(string);
	void setAddress(string);
	void setContactNum(int);

	string getFirstName();
	string getLastName();
	int getAdninId();
	string getPassword();
	string getEmail();
	string getAddress();
	int getContactNum();

	void editProfile(MYSQL* conn);

	void manageStudent(map<int, Student>&, MYSQL* conn);
	void addStudent(map<int, Student>&, MYSQL* conn);
	void removeStudent(map<int, Student>&,MYSQL* conn);
	void editStudentDetails(map<int, Student>&);
	void viewStudentRecord(map<int, Student>&, MYSQL* conn);

	void manageLecturer(map<int, Lecturer>&, MYSQL* conn);
	void addLecturer(map<int, Lecturer>&, MYSQL* conn);
	void removeLecturer(map<int, Lecturer>&, MYSQL* conn);
	void editLecturerDetails(map<int, Lecturer>&);
	void viewSLecturerRecord(map<int, Lecturer>&,MYSQL* conn);


	void manageSubject(map<int, Lecturer>&, map<int, Subject>&, MYSQL* conn);
	void addSubject(map<int, Lecturer>&, map<int, Subject>&, MYSQL* conn);
	void removeSubject(map<int, Subject>&, MYSQL* conn);
	void editSubjectDetails(map<int, Lecturer>&, map<int, Subject>&);
	void viewSubjectRecord(map<int, Subject>&, MYSQL* conn);


	void homeDisplay();
	void profileDisplay();

};

int Admin::adminKey=700;

void Admin::setFirstName(string fName)
{
	firstName=fName;
}

void Admin::setLastName(string lName)
{
	lastName=lName;
}

void Admin::setPassword(string p)
{
	password=p;
}

void Admin::setEmail(string e)
{
	email=e;
}

void Admin::setAddress(string add)
{
	address=add;
}

void Admin::setContactNum(int contNum)
{
	contactNum=contNum;
}

string Admin::getFirstName()
{
	return firstName;
}

string Admin::getLastName()
{
	return lastName;
}

int Admin::getAdninId()
{
	return adminId;
}

string Admin::getPassword()
{
	return password;
}

string Admin::getEmail()
{
	return email;
}

string Admin::getAddress()
{
	return address;
}

int Admin::getContactNum()
{
	return contactNum;
}

void Admin::editProfile(MYSQL* conn)
{
	bool complete=false;
	string fName;
	string lName;
	string p;
	string e;
	string add;
	int contNum;
	int id = getAdninId();
	string aId = to_string(id);
	string qu;
	const char *q;
	int state;
	do
	{
		cout<< "Press 1 to edit First name"<<endl;
		cout<< "Press 2 to edit Last name"<<endl;
		cout<< "Press 3 to edit Password"<<endl;
		cout<< "Press 4 to edit Email"<<endl;
		cout<< "Press 5 to edit Address"<<endl;
		cout<< "Press 6 to edit Contact number"<<endl;
		cout<< "Press 0 to go back"<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1: {cout<<"Set First Name: ";
					cin>>fName;
					setFirstName(fName);
					qu = "UPDATE Admin SET First_Name= '"+fName+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					//system("CLS");
					system("pause");
			break;
			}
			case 2:{ cout<<"Set Last Name: ";
					cin>>lName;
					setLastName(lName);
					qu = "UPDATE Admin SET Last_Name= '"+lName+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 3: {cout<<"Set Password: ";
					cin>>p;
					setPassword(p);
					qu = "UPDATE Admin SET Password= '"+p+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 4:{ cout<<"Set Email: ";
					cin>>e;
					setEmail(e);
					qu = "UPDATE Admin SET Email= '"+e+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 5:{ cout<<"Set Address: ";
					cin>>add;
					setAddress(add);
                    qu = "UPDATE Admin SET Address= '"+add+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 6: { cout<<"Set Contact Number: ";
					cin>>contNum;
					setContactNum(contNum);
					string ctNum = to_string(contNum);
					qu = "UPDATE Admin SET Contact_No = '"+ctNum+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!";
			break;
		}
		system("CLS");
	}while(!complete);
}

void Admin::manageStudent(map<int, Student>& sMap, MYSQL* conn)
{
	bool complete=false;
	do
	{
		cout<< "Press 1 to add a student into record"<<endl;
		cout<< "Press 2 to remove a student from record"<<endl;
		cout<< "Press 3 to edit student details"<<endl;
		cout<< "Press 4 to view student record"<<endl;
		cout<< "Press 0 to go back  "<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1: addStudent(sMap, conn);
			break;
			case 2: removeStudent(sMap, conn);
			break;
			case 3: editStudentDetails(sMap);
			break;
			case 4: { viewStudentRecord(sMap, conn);

					  system("pause");
					  system("CLS"); }
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		//system("CLS");
	}while(!complete);
}

void Admin::addStudent(map<int, Student>& sMap, MYSQL* conn)
{
	string fName;
	string lName;
	string p;
	string e;
	string add;
	int contNum;

	cout<<"Input Student details..."<<endl;

	cout<<"First Name: ";
	cin>>fName;

	cout<<"Last Name: ";
	cin>>lName;

	cout<<"Initial Password for the student: ";
	cin>>p;

	cout<<"Email: ";
	cin>>e;

	cout<<"Address: ";
	cin>>add;

	cout<<"Contact Number: ";
	cin>>contNum;

	Student s(fName,lName,p,e,add,contNum);
	int mapKey=s.getStudentId();
	sMap[mapKey]=s;

    int admId = getAdninId();

    string mKy = to_string(mapKey);
    string cntNm = to_string(contNum);
    string aId = to_string(admId);

    string query="INSERT INTO student (Student_Id,First_Name, Last_Name, Email,Password, Contact_No, Address, Admin_ID) VALUES('"+mKy+"','"+fName+"','"+lName+"','"+e+"','"+p+"','"+cntNm+"','"+add+"','"+aId+"')";
    const char*q = query.c_str();
    mysql_query(conn,q);

    system("pause");
	system("CLS");
}


void Admin::removeStudent(map<int, Student>& sMap, MYSQL* conn)
{
	int removalID;
	for(auto element:sMap)
	{
		cout<<"Student ID: "<<element.first<<" Name: "<<element.second.getFirstName()<<" "<<element.second.getLastName()<<endl;
	}
	cout<<endl<<endl;
    cout<< "Input Student ID to remove the student from record: ";
	cin>>removalID;

	if(sMap.count(removalID))
	sMap.erase(removalID);

    string deleteID = to_string(removalID);
    string q="DELETE FROM student WHERE Student_Id='"+deleteID+"'";
    const char *qstr = q.c_str();
    mysql_query(conn,qstr);

	cout<<"Student with ID"<<removalID<<" has been removed from record"<<endl;

    system("pause");
	system("CLS");
}


void Admin::editStudentDetails(map<int, Student>& sMap)
{
	system("pause");
}

void Admin::viewStudentRecord(map<int, Student>& sMap, MYSQL* conn)
{
	if(!sMap.empty())
	{
		for(auto element:sMap)
		{
			element.second.profileDisplay();
		}
	}
	else
	cout<<"Student record is empty"<<endl;

    /*MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Student");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            cout<<row[i]<<"\t";
        }

        cout<<"\n";

    }

    mysql_free_result(result);//clear result set from memory*/
}


void Admin::manageLecturer(map<int, Lecturer>& lMap, MYSQL* conn)
{
	bool complete=false;
	do
	{
		cout<< "Press 1 to add a lecturer into record"<<endl;
		cout<< "Press 2 to remove a lecturer from record"<<endl;
		cout<< "Press 3 to edit lecturer details"<<endl;
		cout<< "Press 4 to view lecturer record"<<endl;
		cout<< "Press 0 to go back  "<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1: addLecturer(lMap, conn);
			break;
			case 2: removeLecturer(lMap, conn);
			break;
			case 3: editLecturerDetails(lMap);
			break;
			case 4: viewSLecturerRecord(lMap, conn);
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		system("CLS");
	}while(!complete);

}

void Admin::addLecturer(map<int, Lecturer>& lMap, MYSQL* conn)
{
	string fName;
	string lName;
	string p;
	string e;
	string add;
	int contNum;

	cout<<"Input Lecturer details..."<<endl;

	cout<<"First Name: ";
	cin>>fName;

	cout<<"Last Name: ";
	cin>>lName;

	cout<<"Initial Password for the lecturer: ";
	cin>>p;

	cout<<"Email: ";
	cin>>e;

	cout<<"Address: ";
	cin>>add;

	cout<<"Contact Number: ";
	cin>>contNum;

    int admId = getAdninId();

    Lecturer l(fName,lName,p,e,add,contNum);
	int mapKey=l.getlecturerId();
	lMap[mapKey]=l;

    string mKy = to_string(mapKey);
    string cntNm = to_string(contNum);
    string aId = to_string(admId);

    string query="INSERT INTO lecturer (Lecturer_Id, First_Name, Last_Name, Email, Password, Contact_No, Address, Admin_ID) VALUES('"+mKy+"','"+fName+"','"+lName+"','"+e+"','"+p+"','"+cntNm+"','"+add+"','"+aId+"')";
    const char*q = query.c_str();
    mysql_query(conn,q);

    system("pause");
	system("CLS");
}

void Admin::removeLecturer(map<int, Lecturer>& lMap, MYSQL* conn)
{
	int removalID;
	for(auto element:lMap)
	{
		cout<<"Lecturer ID: "<<element.first<<" Name: "<<element.second.getFirstName()<<" "<<element.second.getLastName()<<endl;
	}

	cout<<endl<<endl;
	cout<< "Input Lecturer ID to remove the lecturer from record: ";
	cin>>removalID;

	if(lMap.count(removalID))
	lMap.erase(removalID);

    string deleteID = to_string(removalID);
    string q="DELETE FROM lecturer WHERE Lecturer_Id='"+deleteID+"'";
    const char *qstr = q.c_str();
    mysql_query(conn,qstr);

    cout<<"Lecturer with ID"<<removalID<<" has been removed from record"<<endl;
}

void Admin::editLecturerDetails(map<int, Lecturer>& lMap)
{
    system("pause");
}

void Admin::viewSLecturerRecord(map<int, Lecturer>& lMap, MYSQL* conn)
{
	if(!lMap.empty())
	{
		for(auto element:lMap)
		{
			element.second.profileDisplay();
		}
	}
	else
	cout<<"Subject record is empty"<<endl;

	/*MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Lecturer");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            cout<<row[i]<<"\t";
        }

        cout<<"\n";

    }
    mysql_free_result(result);//clear result set from memory*/

    system("pause");
	system("CLS");
}

void Admin::manageSubject(map<int, Lecturer>& lMap, map<int, Subject>& subMap, MYSQL* conn)
{
	bool complete=false;
	do
	{
		cout<< "Press 1 to add a subject into record"<<endl;
		cout<< "Press 2 to remove a subject from record"<<endl;
		cout<< "Press 3 to edit subject details"<<endl;
		cout<< "Press 0 to go back "<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1: addSubject(lMap, subMap, conn);
			break;
			case 2: removeSubject(subMap, conn);
			break;
			case 3: editSubjectDetails(lMap, subMap);
			break;
			case 4: viewSubjectRecord(subMap, conn);
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		system("CLS");
	}while(!complete);
}

void Admin::addSubject(map<int, Lecturer>& lMap, map<int, Subject>& subMap, MYSQL* conn)
{
    string subName;
	int cdtHr;
	int triWeeks;
    string t;
	string d;
	string crNum;

    cout<<"Input Subject details..."<<endl;

	cout<<"Subject Name: ";
	cin>>subName;

	cout<<"Credit Hour: ";
	cin>>cdtHr;

	cout<<"Number of Trimester Weeks: ";
	cin>>triWeeks;

	Subject sub(subName,cdtHr,triWeeks);

	cout<<"Assign lecturer to the subject...."<<endl;

	int lecID;
	for(auto element:lMap)
	{
		cout<<"Lecturer ID: "<<element.first<<" Name: "<<element.second.getFirstName()<<" "<<element.second.getLastName()<<endl;
	}
	bool done=false;
	do
	{
		cout<< "Input a lecturer ID to assign to the subject: ";
		cin>>lecID;
		if(lMap.count(lecID))
		{
			map<int,Lecturer>::iterator it;
			it = lMap.find(lecID);
			sub.setLecturer(it->second);
			it->second.setAssignedSubjects(sub);
			done=true;
		}
		else
		{
			cout<<"Not found, try again..."<<endl;
		}
	}while(!done);


    int admId = getAdninId();
    int sCode = sub.getsubjectCode();
	string mKy = to_string(sCode);
	string tWeeks = to_string(triWeeks);
	string lcId = to_string(lecID);
	string aId = to_string(admId);
	string cdHr = to_string(cdtHr);
	string query="INSERT INTO subject (Subject_Code, Subject_Name, Credit_Hour, Trimester_Weeks, Admin_Id, Lecturer_Id) VALUES('"+mKy+"', '"+subName+"', '"+cdHr+"', '"+tWeeks+"', '"+aId+"', '"+lcId+"')";
    const char*q = query.c_str();
    mysql_query(conn,q);


	cout<<endl<<"Set class timing and location details..."<<endl;

    bool complete=false;
	char choice;
	do
	{
		cout<<"Day: ";
		cin>>d;

		cout<<"Time: ";
		cin>>t;

		cout<<"Classroom Number: ";
		cin>>crNum;

		ClassTiming ct(t,d,crNum);
		sub.setClassTiming(ct);

        int timingId = ct.getTimingId();
		int subjectCode = sub.getsubjectCode();
		string timeKey = to_string(timingId);
		string subCode = to_string(subjectCode);

        string query="INSERT INTO classtiming (Timing_Id, Time, Day, Class_Room_Number, Subject_Code) VALUES('"+timeKey+"','"+t+"','"+d+"','"+crNum+"','"+subCode+"')";
        const char*qs = query.c_str();
        mysql_query(conn,qs);

        cout<<"Do you want to add another class timing?"<<endl;
		cout<<"Press Y or y for YES"<<endl;
		cout<<"Press any other key for NO"<<endl;
		cout<<"Enter choice: ";
		cin>>choice;
		if(choice=='Y'||choice=='y')
		{

		}
		else
		{
            int mapKey=sub.getsubjectCode();
            subMap[mapKey]=sub;
			complete=true;
		}

	}while(!complete);

    system("pause");
	system("CLS");
}

void Admin::removeSubject(map<int, Subject>& subMap, MYSQL* conn)
{
	int removalID;
	for(auto element:subMap)
	{
		cout<<"Subject ID: "<<element.first<<" Name: "<<element.second.getSubjectName()<<endl;
	}

	cout<<endl<<endl;
	cout<< "Input Subject ID to remove the subject from record: ";
	cin>>removalID;

    if(subMap.count(removalID))
    subMap.erase(removalID);

    string deleteID = to_string(removalID);

    string q1="DELETE FROM classtiming WHERE Subject_Code='"+deleteID+"'";
    const char *qs = q1.c_str();
    mysql_query(conn,qs);

    string q="DELETE FROM subject WHERE Subject_Code='"+deleteID+"'";
    const char *qstr = q.c_str();
    mysql_query(conn,qstr);

    int quo=mysql_query(conn,qstr);
    if(!quo)
    cout<<"Success"<<endl;
    else
    cout<<"Fail error: "<<mysql_error(conn)<<endl;

    cout<<"Subject with ID"<<removalID<<" has been removed from record"<<endl;

    system("pause");
	system("CLS");
}

void Admin::editSubjectDetails(map<int, Lecturer>& lMap, map<int, Subject>& subMap)
{

}

void Admin::viewSubjectRecord(map<int, Subject>& subMap, MYSQL* conn)
{
	if(!subMap.empty())
	{
		for(auto element:subMap)
		{
			element.second.display();
		}
	}
	else
	{
	cout<<"Subject record is empty"<<endl;
	}

	/*MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Subject");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            cout<<row[i]<<"\t";
        }

        cout<<"\n";

    }

    mysql_free_result(result);//clear result set from memory*/
}

void Admin::homeDisplay()
{
	cout<<"Logged in as "<<firstName<<" ID: "<<adminId<<endl<<endl;
}

void Admin::profileDisplay()
{
	cout<< "First name = "<<firstName<<endl;
	cout<< "Last name = "<<lastName<<endl;
	cout<< "ID = "<<adminId<<endl;
	cout<< "Password = "<<password<<endl;
	cout<< "Email = "<<email<<endl;
	cout<< "Address = "<<address<<endl;
	cout<< "Contact number = "<<contactNum<<endl<<endl;
	//system("pause");
	//system("CLS");
}

void ClassTiming::setTimingId(int tId)
 {
	 timingId = tId;
 }

 void ClassTiming::setTime(string tM)
 {
	 time = tM;
 }

 void ClassTiming::setDay(string Day)
 {
	 day = Day;
 }

 void ClassTiming::setClassroomNumber(string classRoomNumber)
 {
	 ClassRoomNumber = classRoomNumber;
 }

 int ClassTiming::getTimingId()
 {
	 return timingId;
 }

 string ClassTiming::getTime()
 {
	 return time;
 }

 string ClassTiming::getDay()
 {
	 return day;
 }

 string ClassTiming::getClassroomNumber()
 {
	 return ClassRoomNumber;
 }

 void ClassTiming::display()
 {
	 cout<< "Day : "<<day<<endl;
	 cout<< "Time : "<<time<<endl;
	 cout<< "Class Room Number : "<<ClassRoomNumber<<endl;
 }



void Lecturer::setPassword(string p)
{
	password=p;
}

void Lecturer::setEmail(string e)
{
	email=e;
}

void Lecturer::setAddress(string add)
{
	address=add;
}

void Lecturer::setContactNum(int contNum)
{
	contactNum=contNum;
}

void Lecturer::setAssignedSubjects(Subject& sub)
{
	int count=0;
	for(int i=0; i<assignedSubjects.size(); i++)
	{
		if(sub.getsubjectCode()!=assignedSubjects[i].getsubjectCode())
		{
			count++;
		}
	}
	if(count==assignedSubjects.size())
	{
		assignedSubjects.push_back(sub);
	}
}

string Lecturer::getFirstName()
{
	return firstName;
}

string Lecturer::getLastName()
{
	return lastName;
}

int Lecturer::getlecturerId()
{
	return lecturerId;
}

string Lecturer::getPassword()
{
	return password;
}

string Lecturer::getEmail()
{
	return email;
}

string Lecturer::getAddress()
{
	return address;
}

int Lecturer::getContactNum()
{
	return contactNum;
}

vector <Subject> Lecturer::getAssignedSubjects()
{
	return assignedSubjects;
}

void Lecturer::editProfile(MYSQL* conn)
{
	bool complete=false;
	string p;
	string e;
	string add;
	int contNum;
	int lecId = getlecturerId();
	string lcID = to_string(lecId);
	string qu;
	const char *q;
	do
	{
		cout<< "Press 1 to edit Password"<<endl;
		cout<< "Press 2 to edit Email"<<endl;
		cout<< "Press 3 to edit Address"<<endl;
		cout<< "Press 4 to edit Contact number"<<endl;
		cout<< "Press 0 to go back"<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1:{ cout<<"Set Password: ";
					cin>>p;
					setPassword(p);
					qu = "UPDATE lecturer SET Password= '"+p+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
            }
			case 2:{ cout<<"Set Email: ";
					cin>>e;
					setEmail(e);
					qu = "UPDATE lecturer SET Email= '"+e+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
            }
			case 3: {cout<<"Set Address: ";
					cin>>add;
					setAddress(add);
					qu = "UPDATE lecturer SET Address= '"+add+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 4:{ cout<<"Set Contact Number: ";
					cin>>contNum;
					setContactNum(contNum);
					string ctNum = to_string(contNum);
					qu = "UPDATE lecturer SET Contact_No= '"+ctNum+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!";
			break;
		}
		system("CLS");
	}while(!complete);
}

void Lecturer::viewSubjectList()
{
	for(int i=0; i<assignedSubjects.size(); i++)
	{
		assignedSubjects[i].display();
		cout<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::viewStudentList(map<int,Subject>&subMap)
{
	bool messi = false;
	vector <Student> studList;
	int subjectCode;

	viewSubjectList();

	cout<< "Enter Subject code to see student list :";
	cin>>subjectCode;

	for(int j=0; j<assignedSubjects.size();j++)
	{
		if(subjectCode==assignedSubjects[j].getsubjectCode())
		{
			cout<< "Student list for Subject Code: "<<subjectCode<<" Name: "<<assignedSubjects[j].getSubjectName()<<endl;
			studList = subMap.at(subjectCode).getStudentList();
			for(int i=0; i<studList.size(); i++)
			{
				studList[i].display();
				cout<<endl<<endl;

			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}

	system("pause");
	system("CLS");
}

void Lecturer::updateLearningMaterials(map<int,Subject>&subMap)
{
	bool messi = false;
	bool done = false;
	int subjectCode;
	int weekNum;
	string materials;

	viewSubjectList();

	cout<< "Enter Subject code to upload learning materials :";
	cin>>subjectCode;

	for(int k=0; k<assignedSubjects.size(); k++)
	{
		if(subjectCode==assignedSubjects[k].getsubjectCode())
		{
			do
			{
				cout<<"Enter Week number: ";
				cin>>weekNum;
				cout<<"Upload materials(string): ";
				cin>>materials;
				subMap.at(subjectCode).setLearningmaterials(weekNum, materials);
				done =true;
			}while(!done);
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::updateAttendance(map<int,Subject>&subMap)
{
	bool messi = false;
	vector <Student> studList;
	int subjectCode;
	double att;
	int studID;
	viewSubjectList();

	cout<< "Enter Subject code to see student list :";
	cin>>subjectCode;

	for(int k=0; k<assignedSubjects.size(); k++)
	{
		if(subjectCode==assignedSubjects[k].getsubjectCode())
		{
			cout<< "Update attendance for Subject Code: "<<subjectCode<<" Name: "<<assignedSubjects[k].getSubjectName()<<endl;
			studList = subMap.at(subjectCode).getStudentList();
			for(int i=0; i<studList.size(); i++)
			{
				cout<<"Student Id "<<studList[i].getStudentId()<<": ";
				cin>>att;
				cout<<endl;
				studID=studList[i].getStudentId();
				subMap.at(subjectCode).setAttendance(studID, att);
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::updateTestResult(map<int,Subject>&subMap)
{
	bool messi = false;
	vector <Student> studList;
	int subjectCode;
	double testScore;
	int studID;
	viewSubjectList();

	cout<< "Enter Subject code to see student list :";
	cin>>subjectCode;

	for(int j=0; j<assignedSubjects.size(); j++)
	{
		if(subjectCode==assignedSubjects[j].getsubjectCode())
		{
			cout<< "Update test result for Subject Code: "<<subjectCode<<" Name: "<<assignedSubjects[j].getSubjectName()<<endl;
			studList = subMap.at(subjectCode).getStudentList();
			for(int i=0; i<studList.size(); i++)
			{
				cout<<"Student ID  "<<studList[i].getStudentId()<<": ";
				cin>>testScore;
				cout<<endl;
				studID=studList[i].getStudentId();
				subMap.at(subjectCode).setTestResult(studID, testScore);
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::updateCourseWork(map<int,Subject>&subMap)
{
	bool messi = false;
	vector <Student> studList;
	int subjectCode;
	double courseMark;
	int studID;
	viewSubjectList();

	cout<< "Enter Subject code to see student list :";
	cin>>subjectCode;

	for(int j=0;j<assignedSubjects.size();j++)
	{
		if(subjectCode==assignedSubjects[j].getsubjectCode())
		{
			cout<< "Update course work marks for Subject Code: "<<subjectCode<<" Name: "<<assignedSubjects[j].getSubjectName()<<endl;
			studList = subMap.at(subjectCode).getStudentList();
			for(int i=0; i<studList.size(); i++)
			{
				cout<<"Student ID  "<<studList[i].getStudentId()<<": ";
				cin>>courseMark;
				cout<<endl;
				studID=studList[i].getStudentId();
				subMap.at(subjectCode).setCourseWork(studID, courseMark);
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::display()
{
	cout<< "Lecturer name = "<<firstName<<" "<<lastName<<endl;
	cout<< "Email = "<<email<<endl;
	cout<< "Contact number = "<<contactNum<<endl;

}

void Lecturer::homeDisplay()
{
	cout<<"Logged in as "<<firstName<<" ID: "<<lecturerId<<endl<<endl;
}

void Lecturer::profileDisplay()
{
	cout<< "First name = "<<firstName<<endl;
	cout<< "Last name = "<<lastName<<endl;
	cout<< "ID = "<<lecturerId<<endl;
	cout<< "Password = "<<password<<endl;
	cout<< "Email = "<<email<<endl;
	cout<< "Address = "<<address<<endl;
	cout<< "Contact number = "<<contactNum<<endl<<endl;
	//system("pause");
	//system("CLS");
}




void Student::setPassword(string p)
{
	password = p;
}

void Student::setEmail(string e)
{
	email = e;
}

void Student::setAddress(string add)
{
	address = add;
}

void Student::setContactNum(int contNum)
{
	contactNum = contNum;
}

void Student::setSubjectList(Subject& sub)
{
	int count=0;
	for(int i=0;i<subjectList.size();i++)
	{
		if(sub.getsubjectCode()!=subjectList[i].getsubjectCode())
		{
			count++;
		}
	}
	if(count==subjectList.size())
	{
		subjectList.push_back(sub);
	}
	else
	{
		cout<< "Subject already exits in your list "<<endl;
	}
}

string Student::getFirstName()
{
	return firstName;
}

string Student::getLastName()
{
	return lastName;
}

int Student::getStudentId()
{
	return studentId;
}

string Student::getPassword()
{
	return password;
}

string Student::getEmail()
{
	return email;
}

string Student::getAddress()
{
	return address;
}

int Student::getContactNum()
{
	return contactNum;
}

vector <Subject> Student:: getSubjectList()
{
	return subjectList;
}

void Student::editProfile(MYSQL* conn)
{
	bool complete=false;
	string p;
	string e;
	string add;
	int contNum;
	int stdId = getStudentId();
	string stID = to_string(stdId);
	string qu;
	const char* q;
	do
	{
		cout<< "Press 1 to edit Password "<<endl;
		cout<< "Press 2 to edit Email "<<endl;
		cout<< "Press 3 to edit Address "<<endl;
		cout<< "Press 4 to edit Contact number "<<endl;
		cout<< "Press 0 to go back "<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1:{ cout<<"Set Password: ";
					cin>>p;
					setPassword(p);
					qu = "UPDATE student SET Password= '"+p+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 2:{ cout<<"Set Email: ";
					cin>>e;
					setEmail(e);
					qu = "UPDATE student SET Email= '"+e+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 3:{ cout<<"Set Address: ";
					cin>>add;
					setAddress(add);
					qu = "UPDATE student SET Address = '"+add+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 4:{ cout<<"Set Contact Number: ";
					cin>>contNum;
					setContactNum(contNum);
					string cntNum = to_string(contNum);
					qu = "UPDATE student SET Contact_No = '"+cntNum+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!";
			break;
		}
		system("CLS");
	}while(!complete);
}

void Student::enrollSubject(map<int, Subject>& subMap, map<int,Student>& stMap)
{
	bool complete=false;

	do
	{
		cout<< "Press 1 to add subject "<<endl;
		cout<< "Press 2 to remove subject"<<endl;
		cout<< "Press 0 to go back "<<endl;
		cout<< "Enter choice: ";
		int choice;
		cin>>choice;
		system("CLS");
		switch (choice)
		{
			case 1: addSubject(subMap,stMap);
			break;
			case 2: removeSubject(subMap,stMap);
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		system("CLS");
	}while(!complete);
}

void Student::addSubject(map<int, Subject>& subMap, map<int,Student>& stMap)
{
	bool complete=false;
	int subjectCode;
	int totalCreditHour=0;
	int crdHour= 0;
	char choice;
	int studentId;
	studentId = getStudentId();
	map<int,Student>::iterator it;
	if(stMap.count(studentId));
	{
		it = stMap.find(studentId);
	}
	for(auto element:subMap)
	{
		cout<< "Subject Code :"<<element.second.getsubjectCode()<< "  Subject Name :"<<element.second.getSubjectName()<<endl;
	}
	do{
		cout<< "To add a subject enter a subject code :";
		cin>>subjectCode;
		if(subMap.count(subjectCode))
		{
			setSubjectList(subMap.at(subjectCode));
			subMap.at(subjectCode).setStudentList(it->second);
			crdHour = subMap.at(subjectCode).getCreditHour();
			totalCreditHour = totalCreditHour + crdHour;
		}
		else
		{
			cout<<"Not found...";
		}
		if(totalCreditHour>20)
		{
			cout<< "Total credit Hour taken :"<<totalCreditHour<<endl;
			cout<< "You have exceded credit hour limit(20), Go back to remove subjects"<<endl;
			system("pause");
			complete=true;

		}
		else{
			cout<<endl;
			cout<<"Do you want add another Subject?"<<endl;
			cout<<"Press Y or y for YES"<<endl;
			cout<<"Press any other key for NO"<<endl;

			cout<<"Enter choice: ";
			cin>>choice;
		if(choice=='Y'||choice=='y')
		{}
		else
			complete=true;
		}

	}while(!complete);
}

void Student::removeSubject(map<int, Subject>& subMap, map<int,Student>& stMap)
{
	bool messi = false;
	int removalID;
	studentId = getStudentId();
	map<int,Student>::iterator it;
	if(stMap.count(studentId));
	{
		it = stMap.find(studentId);
	}
	for(int i=0;i<subjectList.size();i++)
	{
		subjectList[i].display();
		cout<<endl;
	}
	cout<< "Input Subject code to remove the Subject from the List "<<endl;
	cin>>removalID;
	for(int i=0; i<subjectList.size();i++)
	{
		if(removalID == subjectList[i].getsubjectCode())
		{
			subjectList.erase(subjectList.begin()+i);
			subMap.at(removalID).removeStudent(it->second);
			cout<<"Subject Code "<<removalID<<" has been removed from the List"<<endl;
			messi = true;
		}
	}
	if(messi == false )
	{
		cout<< " Not found "<<endl;
	}
}

void Student::viewRegisteredSubject()
{
	for(int i=0;i<subjectList.size();i++)
	{
		subjectList[i].display();
		cout<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewTestResult(map<int,Subject>& subMap)
{
	bool messi = false;
	map <int, double> tstRslt;
	int subjectCode;

	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

	cout<< "Enter Subject code to see test result :";
	cin>>subjectCode;

	for(int j=0; j<subjectList.size(); j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cout<< "------Test Result----"<<endl;
			tstRslt = subMap.at(subjectCode).getTestResult();
			for(auto element:tstRslt)
			{
				cout<<"Student ID: "<<element.first<<" Test Marks: "<<element.second<<endl;

			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "not found"<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewCourseWork(map<int,Subject>& subMap)
{
	bool messi = false;
	int subjectCode;
	map <int, double> crsWrk;
	for(int i=0; i<subjectList.size(); i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

	cout<< "Enter Subject code to see Course Work :";
	cin>>subjectCode;

	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cout<< "-----Course Work-----"<<endl;
			crsWrk = subMap.at(subjectCode).getCourseWork();
			for(auto element: crsWrk)
			{
				cout<<"Student ID: "<<element.first<<" Course work: "<<element.second<<endl;
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "not found"<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewAttendance(map<int,Subject>& subMap)
{
	bool messi = false;
	int subjectCode;
	map <int, double> attndce;
	int stdntId;
	stdntId = getStudentId();

	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

	cout<< "Enter Subject code to see Attendance :";
	cin>>subjectCode;

	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			attndce = subMap.at(subjectCode).getAttendance();
			if(attndce.count(stdntId))
			{
				map<int,double>::iterator it;
				it = attndce.find(stdntId);
				cout<< "Attendance :"<<it->second<<"%"<<endl;
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found "<<endl;
	}
	system("pause");
	system("CLS");
}


void Student::viewClassSchedule()
{
	bool messi = false;
	vector <ClassTiming> cTime;
	int subjectCode;

	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

	cout<< "Enter Subject code to see Class Schedule :";
	cin>>subjectCode;
	cout<<endl;
	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cTime = subjectList[j].getClassTiming();
			j = subjectList.size();
			messi = true;
		}
	}
	if(messi== false)
	{
		cout<< "not found"<<endl;
	}
	else
	{
		for(int k=0;k<cTime.size();k++)
		{
			cTime[k].display();
		}
	}
	system("pause");
	system("CLS");
}

void Student::viewLecturerDetails()
{
	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
		subjectList[i].getLecturer().display();
		cout<<"-------------------------------"<<endl;
		cout<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewLearningMaterials(map<int,Subject>& subMap)
{
	bool messi = false;
	int subjectCode;
	multimap<int,string>lMt;
	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

	cout<< "Enter Subject code to see Learnig Materials :";
	cin>>subjectCode;
	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cout<< "Subject Code: "<<subjectList[j].getsubjectCode()<< " Subject Name :"<<subjectList[j].getSubjectName()<<endl;
			lMt = subMap.at(subjectCode).getLearningmaterials();
			for(auto element:lMt)
			{
				cout<<"Week: "<<element.first<<" "<<element.second<<endl;
			}
			messi = true;
		}
	}
	if(messi== false)
	{
		cout<< "not found"<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::homeDisplay()
{
	cout<<"Logged in as "<<firstName<<" ID: "<<studentId<<endl<<endl;
}

void Student::profileDisplay()
{
	cout<< "First name  "<<firstName<<endl;
	cout<< "Last name  "<<lastName<<endl;
	cout<< "ID  "<<studentId<<endl;
	cout<< "Password  "<<password<<endl;
	cout<< "Email  "<<email<<endl;
	cout<< "Address  "<<address<<endl;
	cout<< "Contact number  "<<contactNum<<endl<<endl;
	//system("pause");
	//system("CLS");
}

void Student::display()
{
	cout<< "First name "<<firstName<< " Last name "<<lastName<<endl;
	cout<< "ID  "<<studentId<<endl;
	cout<< "Email  "<<email<<endl;
	cout<< "Contact number  "<<contactNum<<endl<<endl;
}

void displayMenu();
void adminLogin(map<int,Admin>& aMap, map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap, MYSQL* conn);
void studentLogin(map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap);
void lecturerLogin(map<int,Lecturer>& lecMap, map<int,Student>& stMap, map<int,Subject>& subMap);
template <class T> T getValidatedInput();

template <class T>
T getValidatedInput()
{

    T result;
    cin >> result;

    if (result<0||cin.fail() || cin.get() != '\n')
    {
        cin.clear();

        while (cin.get() != '\n')
            ;


        throw string("Invalid input!!!! Try again...");
    }

    return result;
}

void displayMenu()
{
	system("CLS");
	cout<<"Welcome to Student Learning Management System"<<endl<<endl;
	cout<<"Press 1 to login as admin"<<endl;
	cout<<"Press 2 to login as Student"<<endl;
	cout<<"Press 3 to login as lecturer"<<endl;
	cout<<"Press 4 to close the system"<<endl<<endl;
}


void adminLogin(map<int,Admin>& aMap, map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap, MYSQL* conn)
{
	int aID; bool done=false; int messi=0;
	string aPassword;

	map<int,Admin>::iterator it;

	do
	{
		int c;
		cout<<"---------ADMIN LOGIN-----------"<<endl;
		cout<<"Enter 1 to input login details"<<endl;
		cout<<"Enter 2 to go back to MAIN MENU"<<endl;

		while (true)
		{
		   cout<<"Choice: ";
			try
			{
				c = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl<<endl;
				continue;
			}
			break;
		}

		system("CLS");
		switch(c)
		{
			case 1:
			{
				while (true)
				{
					cout<<"Enter User ID: ";
					try
					{
						aID = getValidatedInput<int>();
					}
					catch (string  e)
					{
						cerr << e << endl<<endl;
						continue;
					}
					break;
				}
				cout<<endl;
				cout<<"Enter password: ";
				cin>>aPassword;
				system("CLS");

				if(aMap.count(aID))
				{
					it = aMap.find(aID);
					if(aPassword==it->second.getPassword())
					{
						done=true;
						messi=1;
					}
				}
				else{
					cout<<"Wrong User ID or password"<<endl;
				}
			break;
			}
			case 2:
			{
				done=true;
			}
	   }
	}while(!done);

	if(messi==1)
	{
		it->second.homeDisplay();
		bool cooper=false;

		do{
			cout<<"Press 1 to view my profile"<<endl;
			cout<<"Press 2 to edit my profile"<<endl;
			cout<<"Press 3 to manage Student"<<endl;
			cout<<"Press 4 to manage Lecturer"<<endl;
			cout<<"Press 5 to manage Subject"<<endl;
			cout<<"Press 0 to logout"<<endl<<endl;

			int choice1;

			while (true)
			{
			cout<<"Choice: ";

			try
			{
				choice1 = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
			}
			system("CLS");

			switch (choice1)
		    {
				case 1:{ it->second.profileDisplay();
						system("pause");
						system("CLS");
				}
				break;
				case 2: it->second.editProfile(conn);
				break;
				case 3: it->second.manageStudent(stMap,conn);
				break;
				case 4: it->second.manageLecturer(lecMap, conn);
				break;
				case 5: it->second.manageSubject(lecMap, subMap, conn);
				break;
				case 0: cooper=true;
				break;

		    }

		}while(!cooper);
	}

}

void studentLogin(map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap,MYSQL* conn)
{
	int stID;
	string stPassword;
	map<int,Student>::iterator it;
	int log=1;
	bool thanos=false;

	do
	{
		int c;
		cout<<"------------Student LOGIN-----------"<<endl;
		cout<<"Enter 1 to input login details"<<endl;
		cout<<"Enter 2 to go back to MAIN MENU"<<endl;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				c = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		}
		system("cls");
		switch(c)
		{
			case 1:
			{
				while (true)
				{
					cout<<"Enter User ID: ";
					try
					{
						stID = getValidatedInput<int>();
					}
					catch (string  e)
					{
						cerr << e << endl<<endl;
						continue;
					}
					break;
				}
				cout<<endl;
				cout<<"Enter password: ";
				cin>>stPassword;
				system("CLS");

				if(stMap.count(stID))
				{
					it = stMap.find(stID);
					if(stPassword==it->second.getPassword())
					{
						thanos=true;
					}
				}
				else{
					cout<<"Wrong User ID or password"<<endl;
				}
			break;
			}
			case 2:
			{
				log=0;
				thanos=true;
				break;
			}
		}

	}while(!thanos);

	if(log!=0)
	{
		it->second.homeDisplay();
		bool sherlock = false;

		do{
			cout<<"Press 1 to view my profile"<<endl;
			cout<<"Press 2 to edit my profile"<<endl;
			cout<<"Press 3 to Enroll Subject"<<endl;
			cout<<"Press 4 to View Registered Subject"<<endl;
			cout<<"Press 5 to View Learning Materials"<<endl;
			cout<<"Press 6 to View Attendance"<<endl;
			cout<<"Press 7 to View TestResult"<<endl;
			cout<<"Press 8 to View CourseWork"<<endl;
			cout<<"Press 9 to View ClassSchedule"<<endl;
			cout<<"Press 10 to View LectureerDetails"<<endl;
			cout<<"Press 0 to logout"<<endl<<endl;

			int choice2;

			while (true)
			{
				cout<<"Choice: ";

				try
				{
					choice2 = getValidatedInput<int>();
				}
				catch (string  e)
				{
					cerr << e << endl;
					continue;
				}

				break;
			}
			system("CLS");

			switch (choice2)
		    {
				case 1:{ it->second.profileDisplay();
							system("pause");
							system("CLS");
				}
				break;
				case 2: it->second.editProfile(conn);
				break;
				case 3: it->second.enrollSubject(subMap,stMap);
				break;
				case 4: it->second.viewRegisteredSubject();
				break;
				case 5: it->second.viewLearningMaterials(subMap);
				break;
				case 6: it->second.viewAttendance(subMap);
				break;
				case 7: it->second.viewTestResult(subMap);
				break;
				case 8: it->second.viewCourseWork(subMap);
				break;
				case 9: it->second.viewClassSchedule();
				break;
				case 10: it->second.viewLecturerDetails();
				break;
				case 0: sherlock=true;
				break;

		    }

		}while(!sherlock);
	 }

}

void lecturerLogin(map<int,Lecturer>& lecMap, map<int,Student>& stMap, map<int,Subject>& subMap, MYSQL* conn)
{
	int lecID;
	string lecPassword;
	map<int,Lecturer>::iterator it;
	int log1=1;
	bool hulk=false;

	do
	{
		int c;
		cout<<"------------Lecturer LOGIN-----------"<<endl;
		cout<<"Enter 1 to input login details"<<endl;
		cout<<"Enter 2 to go back to MAIN MENU"<<endl;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				c = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		}
		system("cls");
		switch(c)
		{
			case 1:
			{
				while (true)
				{
					cout<<"Enter User ID: ";
					try
					{
						lecID = getValidatedInput<int>();
					}
					catch (string  e)
					{
						cerr << e << endl<<endl;
						continue;
					}
					break;
				}
				cout<<endl;
				cout<<"Enter password: ";
				cin>>lecPassword;
				system("CLS");

				if(lecMap.count(lecID))
				{
					it = lecMap.find(lecID);
					if(lecPassword==it->second.getPassword())
					{
						hulk=true;
					}
				}
				else{
					cout<<"Wrong User ID or password"<<endl;
				}
			break;
			}
			case 2:
			{
				log1=0;
				hulk=true;
				break;
			}
		}

	}while(!hulk);
	if(log1!=0)
	{
		it->second.homeDisplay();
		bool naruto = false;

		do{
			cout<<"Press 1 to view my profile"<<endl;
			cout<<"Press 2 to edit my profile"<<endl;
			cout<<"Press 3 to View Assign Subjects"<<endl;
			cout<<"Press 4 to View Student List"<<endl;
			cout<<"Press 5 to Update Learning Materials"<<endl;
			cout<<"Press 6 to Update Attendance"<<endl;
			cout<<"Press 7 to Update Test Result"<<endl;
			cout<<"Press 8 to Update CourseWork"<<endl;
			cout<<"Press 0 to logout"<<endl<<endl;

			int choice3;

			while (true)
			{
				cout<<"Choice: ";

				try
				{
					choice3 = getValidatedInput<int>();
				}
				catch (string  e)
				{
					cerr << e << endl;
					continue;
				}

				break;
			}
			system("CLS");

			switch (choice3)
		    {
				case 1:{ it->second.profileDisplay();
							system("pause");
							system("CLS");
				}
				break;
				case 2: it->second.editProfile(conn);
				break;
				case 3: it->second.viewSubjectList();
				break;
				case 4: it->second.viewStudentList(subMap);
				break;
				case 5: it->second.updateLearningMaterials(subMap);
				break;
				case 6: it->second.updateAttendance(subMap);
				break;
				case 7: it->second.updateTestResult(subMap);
				break;
				case 8: it->second.updateCourseWork(subMap);
				break;
				case 0: naruto=true;
				break;

		    }

		}while(!naruto);
	 }
	}


MYSQL_RES* Perform_Query(MYSQL* connection, const char* query)
{
    // send the query to the database
   if (mysql_query(connection, query))
   {
      cout << "MySQL query error : %s\n" << mysql_error(connection) << endl;
      exit(1);
   }

    return mysql_use_result(connection);
}


void copyAdminDataFrmMySqlToAdminMap(map<int, Admin>& adMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Admin");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string adminId;
    string fName;
    string lName;
    string em;
    string pass;
    string contNum;
    string add;
    int aId=0;
    int cN=0;
    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        adminId=row[0];
                        stringstream geek(adminId);
                        geek >> aId;
                    }

                break;
				case 1: fName=row[1];

				break;
				case 2: lName=row[2];

				break;
				case 3: em=row[3];

				break;
				case 4: pass=row[4];

                break;
				case 5:
				    {
                        contNum=row[5];
                        stringstream geek(contNum);
                        geek >> cN;
                    }

                break;
				case 6: add=row[6];

                break;
            }


        }
        Admin a(aId, fName, lName, pass, em, add, cN);
        adMap[a.getAdninId()]=a;

    }
    mysql_free_result(result);//clear result set from memory

}

void copyStudentDataFrmMySqlToStudentMap(map<int,Student>& stMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Student");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string studId;
    string fName;
    string lName;
    string em;
    string pass;
    string contNum;
    string add;
    int stId=0;
    int cN=0;
    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        studId=row[0];
                        stringstream geek(studId);
                        geek >> stId;
                    }

                break;
				case 1: fName=row[1];

				break;
				case 2: lName=row[2];

				break;
				case 3: em=row[3];

				break;
				case 4: pass=row[4];

                break;
				case 5:
				    {
                        contNum=row[5];
                        stringstream geek(contNum);
                        geek >> cN;
                    }

                break;
				case 6: add=row[6];

                break;
            }

        }
        Student s(stId, fName, lName, pass, em, add, cN);
        stMap[s.getStudentId()]=s;

    }
    mysql_free_result(result);//clear result set from memory
}

void copyLecDataFrmMySqlToLecturerMap(map<int,Lecturer>& lMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Lecturer");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string lecId;
    string fName;
    string lName;
    string em;
    string pass;
    string contNum;
    string add;
    int lId=0;
    int cN=0;
    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        lecId=row[0];
                        stringstream geek(lecId);
                        geek >> lId;
                    }

                break;
				case 1: fName=row[1];

				break;
				case 2: lName=row[2];

				break;
				case 3: em=row[3];

				break;
				case 4: pass=row[4];

                break;
				case 5:
				    {
                        contNum=row[5];
                        stringstream geek(contNum);
                        geek >> cN;
                    }

                break;
				case 6: add=row[6];

                break;
            }
        }
        Lecturer l(lId, fName, lName, pass, em, add, cN);
        lMap[l.getlecturerId()]=l;

    }
    mysql_free_result(result);//clear result set from memory
}

void copySubjectDataFrmMySqlToSubjectMap(map<int, Subject>& subMap, map<int, Lecturer>& lecMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Subject");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string subCode;
    string subName;
    string creditHr;
    string TrimesterWeeks;
    string lecId;
    int sCode=0;
    int credHr=0;
    int triWeeks=0;
    int lId=0;
    int lecturerId;
    ClassTiming ct;

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        subCode=row[0];
                        stringstream geek(subCode);
                        geek >> sCode;
                    }

                break;
				case 1: subName=row[1];

				break;
				case 2:
				    {
                        creditHr=row[2];
                        stringstream geek(creditHr);
                        geek >> credHr;
                    }

				break;
				case 3:
				    {
                        TrimesterWeeks=row[3];
                        stringstream geek(TrimesterWeeks);
                        geek >> triWeeks;
                    }

				break;

				case 4:
                break;

				case 5:
				    {
                        lecId=row[5];
                        stringstream geek(lecId);
                        geek >> lId;
                    }

				break;
            }


            MYSQL_RES *res;
            MYSQL_ROW ro;

            int num_of_fields;

            int j;

            //retrieve data

            mysql_query(conn, "SELECT * FROM classtiming");

            res = mysql_store_result(conn);

            num_of_fields = mysql_num_fields(res);

            string timingId;
            string time;
            string day;
            string classRoomNum;
            string subCode;
            int tId=0;
            int sCode=0;

            while ((ro = mysql_fetch_row(res)))
            {
                if(row[0]==subCode)
                {
                    for(i = 0; i < num_fields; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                {
                                    timingId=row[0];
                                    stringstream geek(timingId);
                                    geek >> tId;
                                }
                            break;

                            case 1: time=row[1];
                            break;

                            case 2: day=row[2];
                            break;

                            case 3: classRoomNum=row[3];
                            break;
                        }//2nd switch case



                    }//2nd for

                }//if
                ct.setTimingId(tId); ct.setTime(time); ct.setDay(day); ct.setClassroomNumber(classRoomNum);


            }//2nd while

            mysql_free_result(res);//clear result set from memory

        }//1st for

        Subject sub(sCode, subName, credHr, triWeeks);

        map<int,Lecturer>::iterator it;
        if(lecMap.count(lId));
        {
            it = lecMap.find(lId);
            sub.setLecturer(it->second);
        }
        sub.setClassTiming(ct);
        subMap[sub.getsubjectCode()]=sub;

    }//1st while

    mysql_free_result(result);//clear result set from memory
}

int main()
{
	string mainServer="127.0.0.1";
    string mainDbUser="root";
    string mainDbPass="";
    MYSQL *connect; //database connection variable
    unsigned int i=0;
    connect=mysql_init(NULL);
    if(!connect)
        cout<<"Couldn't initiate connector\n";

    if (mysql_real_connect(connect, mainServer.c_str(), mainDbUser.c_str(), mainDbPass.c_str(), "slms" ,0,NULL,0))
    {
        /*cout<<"Connection done\n";
        MYSQL_RES* res = Perform_Query(connect, "show tables");
        cout << "Tables in database SLMS" << endl;
        MYSQL_ROW row;
        while ((row = mysql_fetch_row(res)) != NULL)
        {
            cout << row[i] << endl;

        }
        mysql_free_result(res);*/

        map<int, Admin>adminMap;
        map<int, Student>studentMap;
        map<int, Lecturer>lecturerMap;
        map<int, Subject>subjectMap;
        copyAdminDataFrmMySqlToAdminMap(adminMap, connect);
        copyStudentDataFrmMySqlToStudentMap(studentMap, connect);
        copyLecDataFrmMySqlToLecturerMap(lecturerMap, connect);
        copySubjectDataFrmMySqlToSubjectMap(subjectMap, lecturerMap, connect);
        system("pause");
        bool complete=false;

        do{
            displayMenu();
            int choice;
            while (true)
                {
                    cout<<"Choice: ";

                    try
                    {
                        choice = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
            system("CLS");
            switch (choice)
            {
                case 1: adminLogin(adminMap, studentMap, lecturerMap,subjectMap,connect);
                break;
                case 2: studentLogin(studentMap,lecturerMap,subjectMap,connect);
                break;
                case 3: lecturerLogin(lecturerMap,studentMap,subjectMap,connect);
                break;
                case 4:
                {
                        complete=true;
                }
                break;
            }
        }while(!complete);

    }
    else
    {
        cout<<mysql_error(connect)<<endl;
    }




    mysql_close (connect);


}
