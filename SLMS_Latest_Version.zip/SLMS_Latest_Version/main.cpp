#include <iostream>
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"
#include "Admin.h"
#include "Lecturer.h"
#include "Student.h"
#include "Subject.h"
#include "ClassTiming.h"


/*MYSQL_RES* Perform_Query(MYSQL* connection, const char* query)
{
    // send the query to the database
   if (mysql_query(connection, query))
   {
      cout << "MySQL query error : %s\n" << mysql_error(connection) << endl;
      exit(1);
   }

    return mysql_use_result(connection);
}*/
void displayMenu();
void adminLogin(map<int,Admin>& aMap, map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap, MYSQL* conn);
void studentLogin(map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap);
void lecturerLogin(map<int,Lecturer>& lecMap, map<int,Student>& stMap, map<int,Subject>& subMap);
template <class T> T getValidatedInput();

template <class T>
T getValidatedInput()
{

    T result;
    cin >> result;

    if (result<0||cin.fail() || cin.get() != '\n')
    {
        cin.clear();

        while (cin.get() != '\n')
            ;


        throw string("Invalid input!!!! Try again...");
    }

    return result;
}

void displayMenu()
{
	system("CLS");
	cout<<"Welcome to Student Learning Management System"<<endl<<endl;
	cout<<"Press 1 to login as admin"<<endl;
	cout<<"Press 2 to login as Student"<<endl;
	cout<<"Press 3 to login as lecturer"<<endl;
	cout<<"Press 4 to close the system"<<endl<<endl;
}


void adminLogin(map<int,Admin>& aMap, map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap, MYSQL* conn)
{
	int aID; bool done=false; int messi=0;
	string aPassword;

	map<int,Admin>::iterator it;

	do
	{
		int c;
		cout<<"---------ADMIN LOGIN-----------"<<endl;
		cout<<"Enter 1 to input login details"<<endl;
		cout<<"Enter 2 to go back to MAIN MENU"<<endl;

		while (true)
		{
		   cout<<"Choice: ";
			try
			{
				c = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl<<endl;
				continue;
			}
			break;
		}

		system("CLS");
		switch(c)
		{
			case 1:
			{
				while (true)
				{
					cout<<"Enter User ID: ";
					try
					{
						aID = getValidatedInput<int>();
					}
					catch (string  e)
					{
						cerr << e << endl<<endl;
						continue;
					}
					break;
				}
				cout<<endl;
				cout<<"Enter password: ";
				cin>>aPassword;
				system("CLS");

				if(aMap.count(aID))
				{
					it = aMap.find(aID);
					if(aPassword==it->second.getPassword())
					{
						done=true;
						messi=1;
					}
				}
				else{
					cout<<"Wrong User ID or password"<<endl;
				}
			break;
			}
			case 2:
			{
				done=true;
			}
	   }
	}while(!done);

	if(messi==1)
	{
		it->second.homeDisplay();
		bool cooper=false;

		do{
			cout<<"Press 1 to view my profile"<<endl;
			cout<<"Press 2 to edit my profile"<<endl;
			cout<<"Press 3 to manage Student"<<endl;
			cout<<"Press 4 to manage Lecturer"<<endl;
			cout<<"Press 5 to manage Subject"<<endl;
			cout<<"Press 0 to logout"<<endl<<endl;

			int choice1;

			while (true)
			{
			cout<<"Choice: ";

			try
			{
				choice1 = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
			}
			system("CLS");

			switch (choice1)
		    {
				case 1:{ it->second.profileDisplay();
						system("pause");
						system("CLS");
				}
				break;
				case 2: it->second.editProfile(conn);
				break;
				case 3: it->second.manageStudent(stMap,conn);
				break;
				case 4: it->second.manageLecturer(lecMap, conn);
				break;
				case 5: it->second.manageSubject(lecMap, subMap, conn);
				break;
				case 0: cooper=true;
				break;

		    }

		}while(!cooper);
	}

}

void studentLogin(map<int,Student>& stMap, map<int,Lecturer>& lecMap, map<int,Subject>& subMap,MYSQL* conn)
{
	int stID;
	string stPassword;
	map<int,Student>::iterator it;
	int log=1;
	bool thanos=false;

	do
	{
		int c;
		cout<<"------------Student LOGIN-----------"<<endl;
		cout<<"Enter 1 to input login details"<<endl;
		cout<<"Enter 2 to go back to MAIN MENU"<<endl;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				c = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		}
		system("cls");
		switch(c)
		{
			case 1:
			{
				while (true)
				{
					cout<<"Enter User ID: ";
					try
					{
						stID = getValidatedInput<int>();
					}
					catch (string  e)
					{
						cerr << e << endl<<endl;
						continue;
					}
					break;
				}
				cout<<endl;
				cout<<"Enter password: ";
				cin>>stPassword;
				system("CLS");

				if(stMap.count(stID))
				{
					it = stMap.find(stID);
					if(stPassword==it->second.getPassword())
					{
						thanos=true;
					}
				}
				else{
					cout<<"Wrong User ID or password"<<endl;
				}
			break;
			}
			case 2:
			{
				log=0;
				thanos=true;
				break;
			}
		}

	}while(!thanos);

	if(log!=0)
	{
		it->second.homeDisplay();
		bool sherlock = false;

		do{
			cout<<"Press 1 to view my profile"<<endl;
			cout<<"Press 2 to edit my profile"<<endl;
			cout<<"Press 3 to Enroll Subject"<<endl;
			cout<<"Press 4 to View Registered Subject"<<endl;
			cout<<"Press 5 to View Learning Materials"<<endl;
			cout<<"Press 6 to View Attendance"<<endl;
			cout<<"Press 7 to View TestResult"<<endl;
			cout<<"Press 8 to View CourseWork"<<endl;
			cout<<"Press 9 to View ClassSchedule"<<endl;
			cout<<"Press 10 to View LectureerDetails"<<endl;
			cout<<"Press 0 to logout"<<endl<<endl;

			int choice2;

			while (true)
			{
				cout<<"Choice: ";

				try
				{
					choice2 = getValidatedInput<int>();
				}
				catch (string  e)
				{
					cerr << e << endl;
					continue;
				}

				break;
			}
			system("CLS");

			switch (choice2)
		    {
				case 1:{ it->second.profileDisplay();
							system("pause");
							system("CLS");
				}
				break;
				case 2: it->second.editProfile(conn);
				break;
				case 3: it->second.enrollSubject(subMap,stMap,conn);
				break;
				case 4: it->second.viewRegisteredSubject();
				break;
				case 5: it->second.viewLearningMaterials(subMap);
				break;
				case 6: it->second.viewAttendance(subMap);
				break;
				case 7: it->second.viewTestResult(subMap);
				break;
				case 8: it->second.viewCourseWork(subMap);
				break;
				case 9: it->second.viewClassSchedule(subMap);
				break;
				case 10: it->second.viewLecturerDetails();
				break;
				case 0: sherlock=true;
				break;

		    }

		}while(!sherlock);
	 }

}

void lecturerLogin(map<int,Lecturer>& lecMap, map<int,Student>& stMap, map<int,Subject>& subMap, MYSQL* conn)
{
	int lecID;
	string lecPassword;
	map<int,Lecturer>::iterator it;
	int log1=1;
	bool hulk=false;

	do
	{
		int c;
		cout<<"------------Lecturer LOGIN-----------"<<endl;
		cout<<"Enter 1 to input login details"<<endl;
		cout<<"Enter 2 to go back to MAIN MENU"<<endl;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				c = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		}
		system("cls");
		switch(c)
		{
			case 1:
			{
				while (true)
				{
					cout<<"Enter User ID: ";
					try
					{
						lecID = getValidatedInput<int>();
					}
					catch (string  e)
					{
						cerr << e << endl<<endl;
						continue;
					}
					break;
				}
				cout<<endl;
				cout<<"Enter password: ";
				cin>>lecPassword;
				system("CLS");

				if(lecMap.count(lecID))
				{
					it = lecMap.find(lecID);
					if(lecPassword==it->second.getPassword())
					{
						hulk=true;
					}
				}
				else{
					cout<<"Wrong User ID or password"<<endl;
				}
			break;
			}
			case 2:
			{
				log1=0;
				hulk=true;
				break;
			}
		}

	}while(!hulk);
	if(log1!=0)
	{
		it->second.homeDisplay();
		bool naruto = false;

		do{
			cout<<"Press 1 to view my profile"<<endl;
			cout<<"Press 2 to edit my profile"<<endl;
			cout<<"Press 3 to View Assign Subjects"<<endl;
			cout<<"Press 4 to View Student List"<<endl;
			cout<<"Press 5 to Update Learning Materials"<<endl;
			cout<<"Press 6 to Update Attendance"<<endl;
			cout<<"Press 7 to Update Test Result"<<endl;
			cout<<"Press 8 to Update CourseWork"<<endl;
			cout<<"Press 0 to logout"<<endl<<endl;

			int choice3;

			while (true)
			{
				cout<<"Choice: ";

				try
				{
					choice3 = getValidatedInput<int>();
				}
				catch (string  e)
				{
					cerr << e << endl;
					continue;
				}

				break;
			}
			system("CLS");

			switch (choice3)
		    {
				case 1:{ it->second.profileDisplay();
							system("pause");
							system("CLS");
				}
				break;
				case 2: it->second.editProfile(conn);
				break;
				case 3: it->second.viewSubjectList();
                        	system("pause");
                            system("CLS");
				break;
				case 4: it->second.viewStudentList(stMap);
				break;
				case 5: it->second.updateLearningMaterials(subMap);
				break;
				case 6: it->second.updateAttendance(stMap,subMap);
				break;
				case 7: it->second.updateTestResult(subMap,stMap);
				break;
				case 8: it->second.updateCourseWork(subMap,stMap);
				break;
				case 0: naruto=true;
				break;

		    }

		}while(!naruto);
	 }
	}


void copyAdminDataFrmMySqlToAdminMap(map<int, Admin>& adMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Admin");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string adminId;
    string fName;
    string lName;
    string em;
    string pass;
    string contNum;
    string add;
    int aId=0;
    int cN=0;
    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        adminId=row[0];
                        stringstream geek(adminId);
                        geek >> aId;
                    }

                break;
				case 1: fName=row[1];

				break;
				case 2: lName=row[2];

				break;
				case 3: em=row[3];

				break;
				case 4: pass=row[4];

                break;
				case 5:
				    {
                        contNum=row[5];
                        stringstream geek(contNum);
                        geek >> cN;
                    }

                break;
				case 6: add=row[6];

                break;
            }


        }
        Admin a(aId, fName, lName, pass, em, add, cN);
        adMap[a.getAdninId()]=a;

    }
    mysql_free_result(result);//clear result set from memory

}

void copyStudentDataFrmMySqlToStudentMap(map<int,Student>& stMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Student");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string studId;
    string fName;
    string lName;
    string em;
    string pass;
    string contNum;
    string add;
    int stId=0;
    int cN=0;
    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        studId=row[0];
                        stringstream geek(studId);
                        geek >> stId;
                    }

                break;
				case 1: fName=row[1];

				break;
				case 2: lName=row[2];

				break;
				case 3: em=row[3];

				break;
				case 4: pass=row[4];

                break;
				case 5:
				    {
                        contNum=row[5];
                        stringstream geek(contNum);
                        geek >> cN;
                    }

                break;
				case 6: add=row[6];

                break;
            }

        }
        Student s(stId, fName, lName, pass, em, add, cN);
        stMap[s.getStudentId()]=s;

    }
    mysql_free_result(result);//clear result set from memory
}

void copyLecDataFrmMySqlToLecturerMap(map<int,Lecturer>& lMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Lecturer");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string lecId;
    string fName;
    string lName;
    string em;
    string pass;
    string contNum;
    string add;
    int lId=0;
    int cN=0;
    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        lecId=row[0];
                        stringstream geek(lecId);
                        geek >> lId;
                    }

                break;
				case 1: fName=row[1];

				break;
				case 2: lName=row[2];

				break;
				case 3: em=row[3];

				break;
				case 4: pass=row[4];

                break;
				case 5:
				    {
                        contNum=row[5];
                        stringstream geek(contNum);
                        geek >> cN;
                    }

                break;
				case 6: add=row[6];

                break;
            }
        }
        Lecturer l(lId, fName, lName, pass, em, add, cN);
        lMap[l.getlecturerId()]=l;

    }
    mysql_free_result(result);//clear result set from memory
}

void copySubjectDataFrmMySqlToSubjectMap(map<int, Subject>& subMap, map<int, Student>& stMap, map<int, Lecturer>& lecMap, MYSQL* conn)
{

    MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Subject");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    string subCode;
    string subName;
    string creditHr;
    string TrimesterWeeks;
    string lecId;
    int sCode=0;
    int credHr=0;
    int triWeeks=0;
    int lId=0;
    int lecturerId;

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            switch (i)
		    {
				case 0:
				    {
                        subCode=row[0];
                        stringstream geek(subCode);
                        geek >> sCode;
                    }

                break;
				case 1: subName=row[1];

				break;
				case 2:
				    {
                        creditHr=row[2];
                        stringstream geek(creditHr);
                        geek >> credHr;
                    }

				break;
				case 3:
				    {
                        TrimesterWeeks=row[3];
                        stringstream geek(TrimesterWeeks);
                        geek >> triWeeks;
                    }

				break;

				case 4:
                break;

				case 5:
				    {
                        lecId=row[5];
                        stringstream geek(lecId);
                        geek >> lId;
                    }

				break;
            }//1st switch
        }//1st for

        Subject sub(sCode, subName, credHr, triWeeks);

        map<int,Lecturer>::iterator it;
        if(lecMap.count(lId));
        {
            it = lecMap.find(lId);
            sub.setLecturerId(lId);
            it->second.setAssignedSubjects(sub);
        }

        MYSQL_RES *res;
        MYSQL_ROW ro;

        int num_of_fields;

        int j;

        //retrieve data

        mysql_query(conn, "SELECT * FROM classtiming");

        res = mysql_store_result(conn);

        num_of_fields = mysql_num_fields(res);

        string timingId;
        string time;
        string day;
        string classRoomNum;
        int tId=0;

        while ((ro = mysql_fetch_row(res)))
        {
            if(ro[4]==subCode)
            {
                for(j = 0; j < num_fields; j++)
                {
                    switch (j)
                    {
                        case 0:
                            {
                                timingId=ro[0];
                                stringstream geek(timingId);
                                geek >> tId;
                            }
                        break;

                        case 1: time=ro[1];
                        break;

                        case 2: day=ro[2];
                        break;

                        case 3: classRoomNum=ro[3];
                        break;
                    }//2nd switch

                }//2nd for
                ClassTiming ct(tId, time, day, classRoomNum);
                sub.setClassTiming(ct);

            }//1st if

        }//2nd while

        mysql_free_result(res);//clear result set from memory

        MYSQL_RES *re;
        MYSQL_ROW r;

        int nfields;

        int k;

        mysql_query(conn, "SELECT * FROM enroll");

        re = mysql_store_result(conn);

        nfields = mysql_num_fields(re);

        string stu;
        int stId=0;

        while ((r = mysql_fetch_row(re)))
        {
            if(r[1]==subCode)
            {
                for(k = 0; k < nfields; k++)
                {
                    switch (k)
                    {
                        case 0:
                            {
                                stu=r[0];
                                stringstream geek(stu);
                                geek >> stId;
                            }
                        break;

                    }//3rd switch

                }//3rd for
                sub.setStudentId(stId);
                stMap.at(stId).setSubjectList(sub);
            }//2nd if

        }//3rd while

        mysql_free_result(re);//clear result set from memory
        subMap[sub.getsubjectCode()]=sub;

    }//1st while

    mysql_free_result(result);//clear result set from memory
}


int main()
{
	string mainServer="127.0.0.1";
    string mainDbUser="root";
    string mainDbPass="";
    MYSQL *connect; //database connection variable
    unsigned int i=0;
    connect=mysql_init(NULL);
    if(!connect)
        cout<<"Couldn't initiate connector\n";

    if (mysql_real_connect(connect, mainServer.c_str(), mainDbUser.c_str(), mainDbPass.c_str(), "slms" ,0,NULL,0))
    {
        /*cout<<"Connection done\n";
        MYSQL_RES* res = Perform_Query(connect, "show tables");
        cout << "Tables in database SLMS" << endl;
        MYSQL_ROW row;
        while ((row = mysql_fetch_row(res)) != NULL)
        {
            cout << row[i] << endl;

        }
        mysql_free_result(res);*/

        map<int, Admin>adminMap;
        map<int, Student>studentMap;
        map<int, Lecturer>lecturerMap;
        map<int, Subject>subjectMap;
        copyAdminDataFrmMySqlToAdminMap(adminMap, connect);
        copyStudentDataFrmMySqlToStudentMap(studentMap, connect);
        copyLecDataFrmMySqlToLecturerMap(lecturerMap, connect);
        copySubjectDataFrmMySqlToSubjectMap(subjectMap,studentMap, lecturerMap, connect);
        system("pause");
        bool complete=false;

        do{
            displayMenu();
            int choice;
            while (true)
                {
                    cout<<"Choice: ";

                    try
                    {
                        choice = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
            system("CLS");
            switch (choice)
            {
                case 1: adminLogin(adminMap, studentMap, lecturerMap,subjectMap,connect);
                break;
                case 2: studentLogin(studentMap,lecturerMap,subjectMap,connect);
                break;
                case 3: lecturerLogin(lecturerMap,studentMap,subjectMap,connect);
                break;
                case 4:
                {
                        complete=true;
                }
                break;
            }
        }while(!complete);

    }
    else
    {
        cout<<mysql_error(connect)<<endl;
    }




    mysql_close (connect);


}


