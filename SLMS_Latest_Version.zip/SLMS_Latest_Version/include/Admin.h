#ifndef ADMIN_H
#define ADMIN_H

#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"
#include "Lecturer.h"
#include "Student.h"
#include "Subject.h"
#include "ClassTiming.h"

using namespace std;
class Admin
{
private:
	string firstName;
	string lastName;
	int adminId;
	string password;
	string email;
	string address;
	int contactNum;

public:

	static int adminKey;

Admin();
Admin(string fName, string lName, string p, string e, string add, int contNum);

Admin(int aId, string fName, string lName, string p, string e, string add, int contNum);

	void setFirstName(string);
	void setLastName(string);
	void setPassword(string);
	void setEmail(string);
	void setAddress(string);
	void setContactNum(int);

	string getFirstName();
	string getLastName();
	int getAdninId();
	string getPassword();
	string getEmail();
	string getAddress();
	int getContactNum();

	void editProfile(MYSQL* conn);

	void manageStudent(map<int, Student>&, MYSQL* conn);
	void addStudent(map<int, Student>&, MYSQL* conn);
	void removeStudent(map<int, Student>&,MYSQL* conn);
	void editStudentDetails(map<int, Student>&);
	void viewStudentRecord(map<int, Student>&, MYSQL* conn);

	void manageLecturer(map<int, Lecturer>&, MYSQL* conn);
	void addLecturer(map<int, Lecturer>&, MYSQL* conn);
	void removeLecturer(map<int, Lecturer>&, MYSQL* conn);
	void editLecturerDetails(map<int, Lecturer>&);
	void viewSLecturerRecord(map<int, Lecturer>&,MYSQL* conn);


	void manageSubject(map<int, Lecturer>&, map<int, Subject>&, MYSQL* conn);
	void addSubject(map<int, Lecturer>&, map<int, Subject>&, MYSQL* conn);
	void removeSubject(map<int, Subject>&, MYSQL* conn);
	void editSubjectDetails(map<int, Lecturer>&, map<int, Subject>&);
	void viewSubjectRecord(map<int, Subject>&, MYSQL* conn);


	void homeDisplay();
	void profileDisplay();

};
#endif // ADMIN_H
