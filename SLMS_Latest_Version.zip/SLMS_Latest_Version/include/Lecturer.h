#ifndef LECTURER_H
#define LECTURER_H

#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"
#include "Subject.h"
#include "Student.h"
using namespace std;
class Lecturer
{
private:
	string firstName;
	string lastName;
	int lecturerId;
	string password;
	string email;
	string address;
	int contactNum;
	vector <Subject> assignedSubjects;

public:

	static int lecturerKey;

Lecturer();
Lecturer(string fName, string lName, string p, string e, string add, int contNum);
Lecturer(int lecId, string fName, string lName, string p, string e, string add, int contNum);

	void setPassword(string);
	void setEmail(string);
	void setAddress(string);
	void setContactNum(int);
	void setAssignedSubjects(Subject&);

	string getFirstName();
	string getLastName();
	int getlecturerId();
	string getPassword();
	string getEmail();
	string getAddress();
	int getContactNum();
	vector <Subject> getAssignedSubjects();

	void editProfile(MYSQL* conn);

	void viewSubjectList();
	void viewStudentList(map<int,Student>&);
	void updateLearningMaterials(map<int,Subject>&);
	void updateAttendance(map<int,Student>&, map<int,Subject>&);
	void updateTestResult(map<int,Subject>&, map<int,Student>&);
	void updateCourseWork(map<int,Subject>&, map<int,Student>&);

	void display();
	void profileDisplay();
	void homeDisplay();

};
#endif // LECTURER_H
