#ifndef SUBJECT_H
#define SUBJECT_H
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"
#include "ClassTiming.h"

using namespace std;
class Subject
{
private:
	int subjectCode;
	string subjectName;
	int creditHour;
	int trimesterWeeks;
	int lecturerId;
	vector<int>studentId;
	vector <ClassTiming> classTime;
	multimap <int, string> learningMaterials;
	map<int, double> testResult;
	map<int, double> courseWork;
	map<int, double> attendance;

public:

	static int subjectKey;
    Subject();
    Subject(string subName, int cdtHr, int triWeeks);
    Subject(int subCode, string subName, int cdtHr, int triWeeks);
	void setSubjectName(string);
	void setCreditHour(int);
	void setTrimesterWweeks(int);
	void setLecturerId(int);
	void setStudentId(int);
	void setClassTiming(ClassTiming&);
	void setLearningmaterials(int, string);
	void setTestResult(int, double);
	void setCourseWork(int, double);
	void setAttendance(int,double);

	int getsubjectCode();
	string getSubjectName();
	int getCreditHour();
	int getTrimesterWeeks();
	int getLecturerId();
	vector<int> getStudentId();
	vector<ClassTiming> getClassTiming();
	multimap <int, string> getLearningmaterials();
	map <int, double> getTestResult();
	map <int, double> getCourseWork();
	map<int,double> getAttendance();

	void display();

};
#endif // SUBJECT_H
