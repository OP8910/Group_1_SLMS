#ifndef CLASSTIMING_H
#define CLASSTIMING_H
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"



using namespace std;
class ClassTiming
{
private:
    int timingId;
	string time;
	string day;
	string ClassRoomNumber;
public:
	static int timingKey;

    ClassTiming();
    ClassTiming(string tM, string Day, string classRoomNumber);
    ClassTiming(int, string, string, string);
    void setTimingId(int);
	void setTime(string);
	void setDay(string);
	void setClassroomNumber(string);

	int getTimingId();
	string getTime();
	string getDay();
	string getClassroomNumber();


	void display();

};
#endif // CLASSTIMING_H
