#ifndef STUDENT_H
#define STUDENT_H
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <array>
#include<cstdlib>
#include "mysql.h"
#include "Subject.h"

using namespace std;
class Student
{
private:
	string firstName;
	string lastName;
	int studentId;
	string password;
	string email;
	string address;
	int contactNum;
    vector <Subject>subjectList;

public:

static int studentKey;

Student();

Student(string fName, string lName, string p, string e, string add, int contNum);

Student(int studId, string fName, string lName, string p, string e, string add, int contNum);
	void setPassword(string);
	void setEmail(string);
	void setAddress(string);
	void setContactNum(int);
	bool setSubjectList(Subject&);

	string getFirstName();
	string getLastName();
	int getStudentId();
	string getPassword();
	string getEmail();
	string getAddress();
	int getContactNum();
	vector <Subject> getSubjectList();

	void editProfile(MYSQL* conn);

	void enrollSubject(map<int, Subject>&, map<int, Student>&, MYSQL* conn);
	void addSubject(map<int, Subject>&, map<int,Student>&, MYSQL* conn);
	void removeSubject(map<int, Subject>&, map<int,Student>&, MYSQL* conn);

	void viewRegisteredSubject();
	void viewLearningMaterials(map<int,Subject>& );
	void viewAttendance(map<int,Subject>&);
	void viewTestResult(map<int,Subject>&);
	void viewCourseWork(map<int,Subject>&);
	void viewClassSchedule(map<int,Subject>&);
	void viewLecturerDetails();

	void homeDisplay();
	void profileDisplay();
	void display();

};
#endif // STUDENT_H
