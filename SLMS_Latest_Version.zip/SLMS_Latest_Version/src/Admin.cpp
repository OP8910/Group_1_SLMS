#include "Admin.h"
#include <iostream>


template <class T>
T getValidatedInput()
{

    T result;
    cin >> result;

    if (result<0||cin.fail() || cin.get() != '\n')
    {
        cin.clear();

        while (cin.get() != '\n')
            ;


        throw string("Invalid input!!!! Try again...");
    }

    return result;
}

int Admin::adminKey=700;
Admin::Admin()
{
	firstName="";
	lastName="";
	password="";
	email="";
	address="";
	contactNum=0;
	adminId=0;
}

Admin::Admin(string fName, string lName, string p, string e, string add, int contNum)
{
	firstName=fName;
	lastName=lName;
	password=p;
	email=e;
	address=add;
	contactNum=contNum;
	adminKey++;
	adminId=adminKey;
}

Admin::Admin(int aId, string fName, string lName, string p, string e, string add, int contNum)
{
	adminId=aId;
	firstName=fName;
	lastName=lName;
	password=p;
	email=e;
	address=add;
	contactNum=contNum;
	adminKey++;
}


//int Admin::adminKey=700;

void Admin::setFirstName(string fName)
{
	firstName=fName;
}

void Admin::setLastName(string lName)
{
	lastName=lName;
}

void Admin::setPassword(string p)
{
	password=p;
}

void Admin::setEmail(string e)
{
	email=e;
}

void Admin::setAddress(string add)
{
	address=add;
}

void Admin::setContactNum(int contNum)
{
	contactNum=contNum;
}

string Admin::getFirstName()
{
	return firstName;
}

string Admin::getLastName()
{
	return lastName;
}

int Admin::getAdninId()
{
	return adminId;
}

string Admin::getPassword()
{
	return password;
}

string Admin::getEmail()
{
	return email;
}

string Admin::getAddress()
{
	return address;
}

int Admin::getContactNum()
{
	return contactNum;
}

void Admin::editProfile(MYSQL* conn)
{
	bool complete=false;
	string fName;
	string lName;
	string p;
	string e;
	string add;
	int contNum;
	int id = getAdninId();
	string aId = to_string(id);
	string qu;
	const char *q;
	int state;
	do
	{
		cout<< "Press 1 to edit First name"<<endl;
		cout<< "Press 2 to edit Last name"<<endl;
		cout<< "Press 3 to edit Password"<<endl;
		cout<< "Press 4 to edit Email"<<endl;
		cout<< "Press 5 to edit Address"<<endl;
		cout<< "Press 6 to edit Contact number"<<endl;
		cout<< "Press 0 to go back"<<endl;
		//cout<< "Enter choice: ";
		int choice;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				choice = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		}
		system("CLS");
		switch (choice)
		{
			case 1: {cout<<"Set First Name: ";
					cin>>fName;
					setFirstName(fName);
					qu = "UPDATE Admin SET First_Name= '"+fName+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					//system("CLS");
					system("pause");
			break;
			}
			case 2:{ cout<<"Set Last Name: ";
					cin>>lName;
					setLastName(lName);
					qu = "UPDATE Admin SET Last_Name= '"+lName+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 3: {cout<<"Set Password: ";
					cin>>p;
					setPassword(p);
					qu = "UPDATE Admin SET Password= '"+p+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 4:{ cout<<"Set Email: ";
					cin>>e;
					setEmail(e);
					qu = "UPDATE Admin SET Email= '"+e+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 5:{
                    //cin.clear();
                    //cin.ignore(10000,'\n');
                    cout<<"Address: ";
                    getline(cin,add);
					setAddress(add);
                    qu = "UPDATE Admin SET Address= '"+add+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 6: {
			    while (true)
                {
                    cout<<"Contact Number: ";

                    try
                    {
                        contNum = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
					setContactNum(contNum);
					string ctNum = to_string(contNum);
					qu = "UPDATE Admin SET Contact_No = '"+ctNum+"' WHERE Admin_Id = '"+aId+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!";
			break;
		}
		system("CLS");
	}while(!complete);
}

void Admin::manageStudent(map<int, Student>& sMap, MYSQL* conn)
{
	bool complete=false;
	do
	{
		cout<< "Press 1 to add a student into record"<<endl;
		cout<< "Press 2 to remove a student from record"<<endl;
		cout<< "Press 3 to edit student details"<<endl;
		cout<< "Press 4 to view student record"<<endl;
		cout<< "Press 0 to go back  "<<endl;
		int choice;
		while (true)
        {
            cout<< "Enter choice: ";

        try
        {
            choice = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
        }
		system("CLS");
		switch (choice)
		{
			case 1: addStudent(sMap, conn);
			break;
			case 2: removeStudent(sMap, conn);
			break;
			case 3: editStudentDetails(sMap);
			break;
			case 4: { viewStudentRecord(sMap, conn);

					  system("pause");
					  system("CLS"); }
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		//system("CLS");
	}while(!complete);
}

void Admin::addStudent(map<int, Student>& sMap, MYSQL* conn)
{
	string fName;
	string lName;
	string p;
	string e;
	string add;
	int contNum;

	cout<<"Input Student details..."<<endl;

	cout<<"First Name: ";
	cin>>fName;

	cout<<"Last Name: ";
	cin>>lName;

	cout<<"Initial Password for the student: ";
	cin>>p;

	cout<<"Email: ";
	cin>>e;
    cin.ignore(10000,'\n');
	cout<<"Address: ";
	getline(cin,add);

	 while (true)
    {
        cout<<"Contact Number: ";

        try
        {
            contNum = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }

	Student s(fName,lName,p,e,add,contNum);
	int mapKey=s.getStudentId();
	sMap[mapKey]=s;

    int admId = getAdninId();

    string mKy = to_string(mapKey);
    string cntNm = to_string(contNum);
    string aId = to_string(admId);

    string query="INSERT INTO student (Student_Id,First_Name, Last_Name, Email,Password, Contact_No, Address, Admin_ID) VALUES('"+mKy+"','"+fName+"','"+lName+"','"+e+"','"+p+"','"+cntNm+"','"+add+"','"+aId+"')";
    const char*q = query.c_str();
    mysql_query(conn,q);

    system("pause");
	system("CLS");
}


void Admin::removeStudent(map<int, Student>& sMap, MYSQL* conn)
{
	int removalID;
	for(auto element:sMap)
	{
		cout<<"Student ID: "<<element.first<<" Name: "<<element.second.getFirstName()<<" "<<element.second.getLastName()<<endl;
	}
	cout<<endl<<endl;

    while (true)
    {
        cout<< "Input Student ID to remove the student from record: ";

        try
        {
            removalID = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }

	if(sMap.count(removalID))
	sMap.erase(removalID);

    string deleteID = to_string(removalID);
    string q="DELETE FROM student WHERE Student_Id='"+deleteID+"'";
    const char *qstr = q.c_str();
    mysql_query(conn,qstr);

	cout<<"Student with ID"<<removalID<<" has been removed from record"<<endl;

    system("pause");
	system("CLS");
}


void Admin::editStudentDetails(map<int, Student>& sMap)
{
	system("pause");
}

void Admin::viewStudentRecord(map<int, Student>& sMap, MYSQL* conn)
{
	if(!sMap.empty())
	{
		for(auto element:sMap)
		{
			element.second.profileDisplay();
		}
	}
	else
	cout<<"Student record is empty"<<endl;

    /*MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Student");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            cout<<row[i]<<"\t";
        }

        cout<<"\n";

    }

    mysql_free_result(result);//clear result set from memory*/
}


void Admin::manageLecturer(map<int, Lecturer>& lMap, MYSQL* conn)
{
	bool complete=false;
	do
	{
		cout<< "Press 1 to add a lecturer into record"<<endl;
		cout<< "Press 2 to remove a lecturer from record"<<endl;
		cout<< "Press 3 to edit lecturer details"<<endl;
		cout<< "Press 4 to view lecturer record"<<endl;
		cout<< "Press 0 to go back  "<<endl;
		int choice;
		while (true)
        {
            cout<< "Enter choice: ";

        try
        {
            choice = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
        }
		system("CLS");
		switch (choice)
		{
			case 1: addLecturer(lMap, conn);
			break;
			case 2: removeLecturer(lMap, conn);
			break;
			case 3: editLecturerDetails(lMap);
			break;
			case 4: viewSLecturerRecord(lMap, conn);
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		system("CLS");
	}while(!complete);

}

void Admin::addLecturer(map<int, Lecturer>& lMap, MYSQL* conn)
{
	string fName;
	string lName;
	string p;
	string e;
	string add;
	int contNum;

	cout<<"Input Lecturer details..."<<endl;

	cout<<"First Name: ";
	cin>>fName;

	cout<<"Last Name: ";
	cin>>lName;

	cout<<"Initial Password for the lecturer: ";
	cin>>p;

	cout<<"Email: ";
	cin>>e;

    cin.ignore(10000,'\n');
	cout<<"Address: ";
	getline(cin,add);

     while (true)
    {
        cout<<"Contact Number: ";

        try
        {
            contNum = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }
    int admId = getAdninId();

    Lecturer l(fName,lName,p,e,add,contNum);
	int mapKey=l.getlecturerId();
	lMap[mapKey]=l;

    string mKy = to_string(mapKey);
    string cntNm = to_string(contNum);
    string aId = to_string(admId);

    string query="INSERT INTO lecturer (Lecturer_Id, First_Name, Last_Name, Email, Password, Contact_No, Address, Admin_ID) VALUES('"+mKy+"','"+fName+"','"+lName+"','"+e+"','"+p+"','"+cntNm+"','"+add+"','"+aId+"')";
    const char*q = query.c_str();
    mysql_query(conn,q);

    system("pause");
	system("CLS");
}

void Admin::removeLecturer(map<int, Lecturer>& lMap, MYSQL* conn)
{
	int removalID;
	for(auto element:lMap)
	{
		cout<<"Lecturer ID: "<<element.first<<" Name: "<<element.second.getFirstName()<<" "<<element.second.getLastName()<<endl;
	}

	cout<<endl<<endl;
	while (true)
    {
        cout<< "Input Student ID to remove the lecturer from record: ";

        try
        {
            removalID = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }

	if(lMap.count(removalID))
	lMap.erase(removalID);

    string deleteID = to_string(removalID);
    string q="DELETE FROM lecturer WHERE Lecturer_Id='"+deleteID+"'";
    const char *qstr = q.c_str();
    mysql_query(conn,qstr);

    cout<<"Lecturer with ID"<<removalID<<" has been removed from record"<<endl;
}

void Admin::editLecturerDetails(map<int, Lecturer>& lMap)
{
    system("pause");
}

void Admin::viewSLecturerRecord(map<int, Lecturer>& lMap, MYSQL* conn)
{
	if(!lMap.empty())
	{
		for(auto element:lMap)
		{
			element.second.profileDisplay();
		}
	}
	else
	cout<<"Subject record is empty"<<endl;

	/*MYSQL_RES *result;

    MYSQL_ROW row;

    int num_fields;

    int i;

    //retrieve and display data

    mysql_query(conn, "SELECT * FROM Lecturer");

    result = mysql_store_result(conn);

    num_fields = mysql_num_fields(result);

    while ((row = mysql_fetch_row(result)))
    {

        for(i = 0; i < num_fields; i++)
        {
            cout<<row[i]<<"\t";
        }

        cout<<"\n";

    }
    mysql_free_result(result);//clear result set from memory*/

    system("pause");
	system("CLS");
}

void Admin::manageSubject(map<int, Lecturer>& lMap, map<int, Subject>& subMap, MYSQL* conn)
{
	bool complete=false;
	do
	{
		cout<< "Press 1 to add a subject into record"<<endl;
		cout<< "Press 2 to remove a subject from record"<<endl;
		cout<< "Press 3 to edit subject details"<<endl;
		cout<< "Press 4 to view subject records"<<endl;
		cout<< "Press 0 to go back "<<endl;

		int choice;
		while (true)
        {
            cout<< "Enter choice: ";

        try
        {
            choice = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
        }
		system("CLS");
		switch (choice)
		{
			case 1: addSubject(lMap, subMap, conn);
			break;
			case 2: removeSubject(subMap, conn);
			break;
			case 3: editSubjectDetails(lMap, subMap);
			break;
			case 4: viewSubjectRecord(subMap, conn);
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		system("CLS");
	}while(!complete);
}

void Admin::addSubject(map<int, Lecturer>& lMap, map<int, Subject>& subMap, MYSQL* conn)
{
    string subName;
	int cdtHr;
	int triWeeks;
    string t;
	string d;
	string crNum;
	//cin.clear();
    //cin.ignore(10000,'\n');
    cout<<"Input Subject details..."<<endl;
	cout<<"Subject Name: ";
	getline(cin,subName);


	 while (true)
    {
      cout<<"Credit Hour ";

      try
        {
            cdtHr = getValidatedInput<int>();
        }
      catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }


	while (true)
    {
      cout<<"Number of Trimester Weeks: ";

      try
        {
            triWeeks = getValidatedInput<int>();
        }
      catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }

	Subject sub(subName,cdtHr,triWeeks);

	cout<<"Assign lecturer to the subject...."<<endl;

	int lecID;
	for(auto element:lMap)
	{
		cout<<"Lecturer ID: "<<element.first<<" Name: "<<element.second.getFirstName()<<" "<<element.second.getLastName()<<endl;
	}
	bool done=false;
	do
	{
		cout<< "Input a lecturer ID to assign to the subject: ";
		cin>>lecID;
		if(lMap.count(lecID))
		{
			map<int,Lecturer>::iterator it;
			it = lMap.find(lecID);
			sub.setLecturerId(lecID);
			it->second.setAssignedSubjects(sub);
			done=true;
		}
		else
		{
			cout<<"Not found, try again..."<<endl;
		}
	}while(!done);


    int admId = getAdninId();
    int sCode = sub.getsubjectCode();
	string mKy = to_string(sCode);
	string tWeeks = to_string(triWeeks);
	string lcId = to_string(lecID);
	string aId = to_string(admId);
	string cdHr = to_string(cdtHr);
	string query="INSERT INTO subject (Subject_Code, Subject_Name, Credit_Hour, Trimester_Weeks, Admin_Id, Lecturer_Id) VALUES('"+mKy+"', '"+subName+"', '"+cdHr+"', '"+tWeeks+"', '"+aId+"', '"+lcId+"')";
    const char*q = query.c_str();
    mysql_query(conn,q);


	cout<<endl<<"Set class timing and location details..."<<endl;

    bool complete=false;
	char choice;
	do
	{
        cout<<"Day: ";
		cin>>d;
        cin.ignore(10000,'\n');
		cout<<"Time: ";
		getline(cin,t);
        cout<<"Classroom Number: ";
        cin>>crNum;

		ClassTiming ct(t,d,crNum);
		sub.setClassTiming(ct);

        int timingId = ct.getTimingId();
		int subjectCode = sub.getsubjectCode();
		string timeKey = to_string(timingId);
		string subCode = to_string(subjectCode);

        string query="INSERT INTO classtiming (Timing_Id, Time, Day, Class_Room_Number, Subject_Code) VALUES('"+timeKey+"','"+t+"','"+d+"','"+crNum+"','"+subCode+"')";
        const char*qs = query.c_str();
        mysql_query(conn,qs);

        cout<<"Do you want to add another class timing?"<<endl;
		cout<<"Press Y or y for YES"<<endl;
		cout<<"Press any other key for NO"<<endl;
		cout<<"Enter choice: ";
		cin>>choice;
		if(choice=='Y'||choice=='y')
		{

		}
		else
		{
            int mapKey=sub.getsubjectCode();
            subMap[mapKey]=sub;
			complete=true;
		}

	}while(!complete);

    system("pause");
	system("CLS");
}

void Admin::removeSubject(map<int, Subject>& subMap, MYSQL* conn)
{
	int removalID;
	for(auto element:subMap)
	{
		cout<<"Subject ID: "<<element.first<<" Name: "<<element.second.getSubjectName()<<endl;
	}

	cout<<endl<<endl;
	while (true)
    {
        cout<< "Input Subject ID to remove the subject from record: ";

        try
        {
            removalID = getValidatedInput<int>();
        }
        catch (string  e)
        {
            cerr << e << endl;
            continue;
        }

        break;
    }

    if(subMap.count(removalID))
    {
    subMap.erase(removalID);

    string deleteID = to_string(removalID);

    string q1="DELETE FROM classtiming WHERE Subject_Code='"+deleteID+"'";
    const char *qs = q1.c_str();
    mysql_query(conn,qs);

    string q="DELETE FROM subject WHERE Subject_Code='"+deleteID+"'";
    const char *qstr = q.c_str();
    mysql_query(conn,qstr);



    cout<<"Subject with ID"<<removalID<<" has been removed from record"<<endl;
    }
    else
        cout<< "Subject not found..."<<endl;
    system("pause");
	system("CLS");
}

void Admin::editSubjectDetails(map<int, Lecturer>& lMap, map<int, Subject>& subMap)
{

}

void Admin::viewSubjectRecord(map<int, Subject>& subMap, MYSQL* conn)
{
	if(!subMap.empty())
	{
		for(auto element:subMap)
		{
			element.second.display();
		}
	}
	else
	{
	cout<<"Subject record is empty"<<endl;
	}
    system("pause");
	system("CLS");

}

void Admin::homeDisplay()
{
	cout<<"Logged in as "<<firstName<<" ID: "<<adminId<<endl<<endl;
}

void Admin::profileDisplay()
{
	cout<< "First name = "<<firstName<<endl;
	cout<< "Last name = "<<lastName<<endl;
	cout<< "ID = "<<adminId<<endl;
	cout<< "Password = "<<password<<endl;
	cout<< "Email = "<<email<<endl;
	cout<< "Address = "<<address<<endl;
	cout<< "Contact number = "<<contactNum<<endl<<endl;
	//system("pause");
	//system("CLS");
}
