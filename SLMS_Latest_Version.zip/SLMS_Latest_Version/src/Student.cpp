#include "Student.h"
#include <iostream>

template <class T>
T getValidatedInput()
{

    T result;
    cin >> result;

    if (result<0||cin.fail() || cin.get() != '\n')
    {
        cin.clear();

        while (cin.get() != '\n')
            ;


        throw string("Invalid input!!!! Try again...");
    }

    return result;
}

int Student::studentKey = 18000;
Student::Student()
{
	firstName = "";
	lastName = "";
	studentId = 0;
	password = "";
	email = "";
	address = "";
	contactNum = 0;
}

Student::Student(string fName, string lName, string p, string e, string add, int contNum)
{
	firstName = fName;
	lastName = lName;
	password = p;
	email = e;
	address = add;
	contactNum = contNum;
	studentKey++;
	studentId = studentKey;
}

Student::Student(int studId, string fName, string lName, string p, string e, string add, int contNum)
{
    studentId = studId;
	firstName = fName;
	lastName = lName;
	password = p;
	email = e;
	address = add;
	contactNum = contNum;
	studentKey++;
}


void Student::setPassword(string p)
{
	password = p;
}

void Student::setEmail(string e)
{
	email = e;
}

void Student::setAddress(string add)
{
	address = add;
}

void Student::setContactNum(int contNum)
{
	contactNum = contNum;
}

bool Student::setSubjectList(Subject& sub)
{
	int count=0;
	for(int i=0;i<subjectList.size();i++)
	{
		if(sub.getsubjectCode()!=subjectList[i].getsubjectCode())
		{
			count++;
		}
	}
	if(count==subjectList.size())
	{
		subjectList.push_back(sub);
		return true;
	}
	else
	{
		cout<< "Subject already exits in your list "<<endl;
		return false;
	}
}


string Student::getFirstName()
{
	return firstName;
}

string Student::getLastName()
{
	return lastName;
}

int Student::getStudentId()
{
	return studentId;
}

string Student::getPassword()
{
	return password;
}

string Student::getEmail()
{
	return email;
}

string Student::getAddress()
{
	return address;
}

int Student::getContactNum()
{
	return contactNum;
}

vector <Subject> Student:: getSubjectList()
{
	return subjectList;
}

void Student::editProfile(MYSQL* conn)
{
	bool complete=false;
	string p;
	string e;
	string add;
	int contNum;
	int stdId = getStudentId();
	string stID = to_string(stdId);
	string qu;
	const char* q;
	do
	{
		cout<< "Press 1 to edit Password "<<endl;
		cout<< "Press 2 to edit Email "<<endl;
		cout<< "Press 3 to edit Address "<<endl;
		cout<< "Press 4 to edit Contact number "<<endl;
		cout<< "Press 0 to go back "<<endl;
		int choice;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				choice = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
		system("CLS");
		switch (choice)
		{
			case 1:{ cout<<"Set Password: ";
					cin>>p;
					setPassword(p);
					qu = "UPDATE student SET Password= '"+p+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 2:{ cout<<"Set Email: ";
					cin>>e;
					setEmail(e);
					qu = "UPDATE student SET Email= '"+e+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 3:{ cout<<"Set Address: ";
					getline(cin,add);
					setAddress(add);
					qu = "UPDATE student SET Address = '"+add+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 4:{ while (true)
                {
                    cout<<"Contact Number: ";

                    try
                    {
                        contNum = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
					setContactNum(contNum);
					string cntNum = to_string(contNum);
					qu = "UPDATE student SET Contact_No = '"+cntNum+"' WHERE Student_ID = '"+stID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!";
			break;
		}
		system("CLS");
	}while(!complete);
}

void Student::enrollSubject(map<int, Subject>& subMap, map<int,Student>& stMap,MYSQL* conn)
{
	bool complete=false;

	do
	{
		cout<< "Press 1 to add subject "<<endl;
		cout<< "Press 2 to remove subject"<<endl;
		cout<< "Press 0 to go back "<<endl;
		int choice;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				choice = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
		system("CLS");
		switch (choice)
		{
			case 1: addSubject(subMap,stMap,conn);
			break;
			case 2: removeSubject(subMap,stMap,conn);
			break;
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!"<<endl;
			break;
		}
		system("CLS");
	}while(!complete);
}

void Student::addSubject(map<int, Subject>& subMap, map<int,Student>& stMap, MYSQL* conn)
{
	bool complete=false;
	int subjectCode;
	int totalCreditHour=0;

	char choice;
	int studentId;
	studentId = getStudentId();

	for(auto element:subMap)
	{
		cout<< "Subject Code :"<<element.second.getsubjectCode()<< "  Subject Name :"<<element.second.getSubjectName()<<endl;
	}
	do{
		while (true)
		{
			cout<< "To add a subject enter a subject code :";

			try
			{
				subjectCode = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
		if(subMap.count(subjectCode))
		{
			if(setSubjectList(subMap.at(subjectCode)))
			{
                vector <Subject>subList = getSubjectList();
                for(int i=0; i<subList.size(); i++)
                totalCreditHour = totalCreditHour + subList[i].getCreditHour();
                cout<< "Total credit Hour taken :"<<totalCreditHour<<endl;

                subMap.at(subjectCode).setStudentId(studentId);

                string sID = to_string(studentId);
                string sCode = to_string(subjectCode);

                string query="INSERT INTO enroll (Student_Id, Subject_Code) VALUES('"+sID+"','"+sCode+"')";
                const char*qs = query.c_str();
                mysql_query(conn,qs);
            }
		}
		else
		{
			cout<<"Not found...";
		}
		if(totalCreditHour>20)
		{
			cout<< "You have exceeded credit hour limit(20), Go back to remove subjects"<<endl;
			system("pause");
			complete=true;

		}
		else
        {
			totalCreditHour = 0;
			cout<<endl;
			cout<<"Do you want add another Subject?"<<endl;
			cout<<"Press Y or y for YES"<<endl;
			cout<<"Press any other key for NO"<<endl;

			cout<<"Enter choice: ";
			cin>>choice;
            if(choice=='Y'||choice=='y')
            {}
            else
                complete=true;
        }

	}while(!complete);
}

void Student::removeSubject(map<int, Subject>& subMap, map<int,Student>& stMap, MYSQL* conn)
{
	bool messi = false;
	int removalID;
	studentId = getStudentId();
	map<int,Student>::iterator it;
	if(stMap.count(studentId));
	{
		it = stMap.find(studentId);
	}
	for(int i=0;i<subjectList.size();i++)
	{
		subjectList[i].display();
		cout<<endl;
	}
	while (true)
		{
			cout<< "Input Subject code to remove the Subject from the List "<<endl;

			try
			{
				removalID = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
	for(int i=0; i<subjectList.size();i++)
	{
		if(removalID == subjectList[i].getsubjectCode())
		{
			subjectList.erase(subjectList.begin()+i);

			string deleteID = to_string(removalID);
            string q1="DELETE FROM enroll WHERE Subject_Code='"+deleteID+"'";
            const char *qs = q1.c_str();
            mysql_query(conn,qs);

            cout<<"Subject Code "<<removalID<<" has been removed from the List"<<endl;

            messi = true;
		}
	}
	if(messi == false )
	{
		cout<< " Not found "<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewRegisteredSubject()
{
	for(int i=0;i<subjectList.size();i++)
	{
		subjectList[i].display();
		cout<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewTestResult(map<int,Subject>& subMap)
{
	bool messi = false;
	map <int, double> tstRslt;
	int subjectCode;

	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

    while (true)
		{
			cout<< "Enter Subject code to see test result :";

			try
			{
				subjectCode = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
	for(int j=0; j<subjectList.size(); j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cout<< "------Test Result----"<<endl;
			tstRslt = subMap.at(subjectCode).getTestResult();
			for(auto element:tstRslt)
			{
				cout<<"Student ID: "<<element.first<<" Test Marks: "<<element.second<<endl;

			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "not found"<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewCourseWork(map<int,Subject>& subMap)
{
	bool messi = false;
	int subjectCode;
	map <int, double> crsWrk;
	for(int i=0; i<subjectList.size(); i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}

	while (true)
		{
			cout<< "Enter Subject code to see Course Work :";

			try
			{
				subjectCode = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};


	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cout<< "-----Course Work-----"<<endl;
			crsWrk = subMap.at(subjectCode).getCourseWork();
			for(auto element: crsWrk)
			{
				cout<<"Student ID: "<<element.first<<" Course work: "<<element.second<<endl;
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "not found"<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewAttendance(map<int,Subject>& subMap)
{
	bool messi = false;
	int subjectCode;
	map <int, double> attndce;
	int stdntId;
	stdntId = getStudentId();

	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}


	while (true)
		{
			cout<< "Enter Subject code to see Attendance :";

			try
			{
				subjectCode = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};

	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			attndce = subMap.at(subjectCode).getAttendance();
			if(attndce.count(stdntId))
			{
				map<int,double>::iterator it;
				it = attndce.find(stdntId);
				cout<< "Attendance :"<<it->second<<"%"<<endl;
			}
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found "<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::viewClassSchedule(map<int,Subject>& subMap)
{
	bool messi = false;
	vector <ClassTiming> cTime;
	int subjectCode;

	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}


	while (true)
		{
            cout<< "Enter Subject code to see Class Schedule :";

			try
			{
				subjectCode = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
	cout<<endl;
	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cTime = subMap.at(subjectCode).getClassTiming();
			j = subjectList.size();
			messi = true;
		}
	}
	if(messi== false)
	{
		cout<< "not found"<<endl;
	}
	else
	{
		for(int k=0;k<cTime.size();k++)
		{
			cTime[k].display();
		}
	}
	system("pause");
	system("CLS");
}

void Student::viewLecturerDetails()
{
	/*for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
		subjectList[i].getLecturer().display();
		cout<<"-------------------------------"<<endl;
		cout<<endl;
	}*/
	system("pause");
	system("CLS");
}

void Student::viewLearningMaterials(map<int,Subject>& subMap)
{
	bool messi = false;
	int subjectCode;
	multimap<int,string>lMt;
	for(int i=0;i<subjectList.size();i++)
	{
		cout<< "Subject Code "<<subjectList[i].getsubjectCode()<< " Subject Name "<<subjectList[i].getSubjectName()<<endl;
	}


	while (true)
		{
            cout<< "Enter Subject code to see Learning Materials :";

			try
			{
				subjectCode = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		};
	for(int j=0;j<subjectList.size();j++)
	{
		if(subjectCode==subjectList[j].getsubjectCode())
		{
			cout<< "Subject Code: "<<subjectList[j].getsubjectCode()<< " Subject Name :"<<subjectList[j].getSubjectName()<<endl;
			lMt = subMap.at(subjectCode).getLearningmaterials();
			for(auto element:lMt)
			{
				cout<<"Week "<<element.first<<": "<<element.second<<endl;
			}
			messi = true;
		}
	}
	if(messi== false)
	{
		cout<< "not found"<<endl;
	}
	system("pause");
	system("CLS");
}

void Student::homeDisplay()
{
	cout<<"Logged in as "<<firstName<<" ID: "<<studentId<<endl<<endl;
}

void Student::profileDisplay()
{
	cout<< "First name  "<<firstName<<endl;
	cout<< "Last name  "<<lastName<<endl;
	cout<< "ID  "<<studentId<<endl;
	cout<< "Password  "<<password<<endl;
	cout<< "Email  "<<email<<endl;
	cout<< "Address  "<<address<<endl;
	cout<< "Contact number  "<<contactNum<<endl<<endl;
	//system("pause");
	//system("CLS");
}

void Student::display()
{
	cout<< "First name "<<firstName<< " Last name "<<lastName<<endl;
	cout<< "ID  "<<studentId<<endl;
	cout<< "Email  "<<email<<endl;
	cout<< "Contact number  "<<contactNum<<endl<<endl;
}

