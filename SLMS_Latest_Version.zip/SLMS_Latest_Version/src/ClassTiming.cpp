#include "ClassTiming.h"
#include<iostream>

int ClassTiming::timingKey=30000;

ClassTiming::ClassTiming()
 {
	timingId = 0;
	time = "";
	day = "";
	ClassRoomNumber = "";
 }

ClassTiming::ClassTiming(string tM, string Day, string classRoomNumber)
 {
	time = tM;
	day = Day;
	ClassRoomNumber = classRoomNumber;
	timingKey++;
	timingId = timingKey;
 }

 ClassTiming::ClassTiming(int tId, string tM, string Day, string classRoomNumber)
 {
	timingId = tId;
	time = tM;
	day = Day;
	ClassRoomNumber = classRoomNumber;
	timingKey++;
 }

void ClassTiming::setTimingId(int tId)
 {
	 timingId = tId;
 }

 void ClassTiming::setTime(string tM)
 {
	 time = tM;
 }

 void ClassTiming::setDay(string Day)
 {
	 day = Day;
 }

 void ClassTiming::setClassroomNumber(string classRoomNumber)
 {
	 ClassRoomNumber = classRoomNumber;
 }

 int ClassTiming::getTimingId()
 {
	 return timingId;
 }

 string ClassTiming::getTime()
 {
	 return time;
 }

 string ClassTiming::getDay()
 {
	 return day;
 }

 string ClassTiming::getClassroomNumber()
 {
	 return ClassRoomNumber;
 }

 void ClassTiming::display()
 {
	 cout<<endl;
	 cout<< "Day : "<<day<<endl;
	 cout<< "Time : "<<time<<endl;
	 cout<< "Class Room Number : "<<ClassRoomNumber<<endl;
 }
