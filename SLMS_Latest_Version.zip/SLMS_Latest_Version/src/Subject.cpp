#include "Subject.h"
#include<iostream>
int Subject::subjectKey=8000;

Subject::Subject()
{

}

Subject::Subject(string subName, int cdtHr, int triWeeks)
{
	subjectName=subName;
	creditHour=cdtHr;
	trimesterWeeks=triWeeks;
	subjectKey++;
	subjectCode=subjectKey;
}

Subject::Subject(int subCode, string subName, int cdtHr, int triWeeks)
{
	subjectCode=subCode;
	subjectName=subName;
	creditHour=cdtHr;
	trimesterWeeks=triWeeks;
	subjectKey++;
}

void Subject::setSubjectName(string subName)
{
	subjectName=subName;
}

void Subject::setCreditHour(int cdtHr)
{
	creditHour=cdtHr;
}


void Subject::setTrimesterWweeks(int triWeeks)
{
	trimesterWeeks=triWeeks;
}

void Subject::setLecturerId(int lecId)
{
    lecturerId = lecId;
}

void Subject::setStudentId(int studId)
{
    int count=0;
	for(int i=0;i<studentId.size();i++)
	{
		if(studId!=studentId[i])
		{
			count++;
		}
	}
	if(count==studentId.size())
	{
		studentId.push_back(studId);
	}
}


void Subject::setClassTiming(ClassTiming& ct)
{

		classTime.push_back(ct);
}

void Subject::setLearningmaterials(int index, string materials)
{
	learningMaterials.insert({index,materials});
}

void Subject::setTestResult(int sID, double testScore)
{
	testResult[sID]=testScore;
}


void Subject::setCourseWork(int sID, double courseMark)
{
	courseWork[sID]=courseMark;
}


void Subject::setAttendance(int sID, double att)
{
	attendance[sID]=att;
}



int Subject::getsubjectCode()
{
	return subjectCode;
}


string Subject::getSubjectName()
{
	return subjectName;
}


int Subject::getCreditHour()
{
	return creditHour;
}


int Subject::getTrimesterWeeks()
{
	return trimesterWeeks;
}

int Subject::getLecturerId()
{
	return lecturerId;
}

vector<int> Subject::getStudentId()
{
	return studentId;
}

vector<ClassTiming> Subject::getClassTiming()
{
	return classTime;
}

multimap <int, string> Subject::getLearningmaterials()
{
	return learningMaterials;
}

map <int, double> Subject::getTestResult()
{
	return testResult;
}


map <int, double> Subject::getCourseWork()
{
	return courseWork;
}

map <int, double> Subject::getAttendance()
{
	return attendance;
}

void Subject::display()
{
	cout<<endl;
	cout<<"Subject Name: "<<subjectName<<endl;
	cout<<"Subject Code: "<<subjectCode<<endl;
	cout<<"Credit Hour: "<<creditHour<<endl;
	cout<<"Trimester Length: "<<trimesterWeeks<<endl;
	cout<<"---------------------------------------------------------"<<endl;

}
