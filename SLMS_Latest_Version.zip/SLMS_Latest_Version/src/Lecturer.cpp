#include "Lecturer.h"
#include <iostream>

template <class T>
T getValidatedInput()
{

    T result;
    cin >> result;

    if (result<0||cin.fail() || cin.get() != '\n')
    {
        cin.clear();

        while (cin.get() != '\n')
            ;


        throw string("Invalid input!!!! Try again...");
    }

    return result;
}

int Lecturer::lecturerKey=12000;
Lecturer::Lecturer()
{
	firstName="";
	lastName="";
	password="";
	email="";
	address="";
	contactNum=0;
	lecturerId=0;
}

Lecturer::Lecturer(string fName, string lName, string p, string e, string add, int contNum)
{
	firstName=fName;
	lastName=lName;
	password=p;
	email=e;
	address=add;
	contactNum=contNum;
	lecturerKey++;
	lecturerId=lecturerKey;
}


Lecturer::Lecturer(int lecId, string fName, string lName, string p, string e, string add, int contNum)
{
    lecturerId = lecId;
	firstName = fName;
	lastName = lName;
	password = p;
	email = e;
	address = add;
	contactNum = contNum;
	lecturerKey++;
}

void Lecturer::setPassword(string p)
{
	password=p;
}

void Lecturer::setEmail(string e)
{
	email=e;
}

void Lecturer::setAddress(string add)
{
	address=add;
}

void Lecturer::setContactNum(int contNum)
{
	contactNum=contNum;
}

void Lecturer::setAssignedSubjects(Subject& sub)
{
	int count=0;
	for(int i=0; i<assignedSubjects.size(); i++)
	{
		if(sub.getsubjectCode()!=assignedSubjects[i].getsubjectCode())
		{
			count++;
		}
	}
	if(count==assignedSubjects.size())
	{
		assignedSubjects.push_back(sub);
	}
}

string Lecturer::getFirstName()
{
	return firstName;
}

string Lecturer::getLastName()
{
	return lastName;
}

int Lecturer::getlecturerId()
{
	return lecturerId;
}

string Lecturer::getPassword()
{
	return password;
}

string Lecturer::getEmail()
{
	return email;
}

string Lecturer::getAddress()
{
	return address;
}

int Lecturer::getContactNum()
{
	return contactNum;
}

vector <Subject> Lecturer::getAssignedSubjects()
{
	return assignedSubjects;
}

void Lecturer::editProfile(MYSQL* conn)
{
	bool complete=false;
	string p;
	string e;
	string add;
	int contNum;
	int lecId = getlecturerId();
	string lcID = to_string(lecId);
	string qu;
	const char *q;
	do
	{
		cout<< "Press 1 to edit Password"<<endl;
		cout<< "Press 2 to edit Email"<<endl;
		cout<< "Press 3 to edit Address"<<endl;
		cout<< "Press 4 to edit Contact number"<<endl;
		cout<< "Press 0 to go back"<<endl;
		int choice;
		while (true)
		{
			cout<<"Choice: ";

			try
			{
				choice = getValidatedInput<int>();
			}
			catch (string  e)
			{
				cerr << e << endl;
				continue;
			}

			break;
		}
		system("CLS");
		switch (choice)
		{
			case 1:{ cout<<"Set Password: ";
					cin>>p;
					setPassword(p);
					qu = "UPDATE lecturer SET Password= '"+p+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
            }
			case 2:{ cout<<"Set Email: ";
					cin>>e;
					setEmail(e);
					qu = "UPDATE lecturer SET Email= '"+e+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
            }
			case 3: {cout<<"Set Address: ";
					getline(cin,add);
					setAddress(add);
					qu = "UPDATE lecturer SET Address= '"+add+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 4:{
					while (true)
                    {
                        cout<<"Set Contact Number: ";

                        try
                        {
                            contNum = getValidatedInput<int>();
                        }
                        catch (string  e)
                        {
                            cerr << e << endl;
                            continue;
                        }

                    break;
                    }
					setContactNum(contNum);
					string ctNum = to_string(contNum);
					qu = "UPDATE lecturer SET Contact_No= '"+ctNum+"' WHERE Lecturer_ID = '"+lcID+"'";
					q = qu.c_str();
                    mysql_query(conn,q);
					cout<<"Updated..."<<endl;
					system("pause");
			break;
			}
			case 0: complete=true;
			break;
			default: cout<<"Invalid input, try again!!!";
			break;
		}
		system("CLS");
	}while(!complete);
}

void Lecturer::viewSubjectList()
{
	for(int i=0; i<assignedSubjects.size(); i++)
	{
		assignedSubjects[i].display();
		cout<<endl;
	}
}

void Lecturer::viewStudentList(map<int,Student>&stMap)
{
	bool messi = false;
	//vector <Student> studList;
	vector <Subject> subList;

	int subjectCode;

	viewSubjectList();

    while (true)
    {
        cout<< "Enter Subject code to see student list :";

        try
        {
           subjectCode = getValidatedInput<int>();
        }
        catch (string  e)
        {
           cerr << e << endl;
           continue;
        }

        break;
    }
	for(auto element:stMap)
	{
        subList = element.second.getSubjectList();
        for(int i=0; i<subList.size(); i++)
        {
            if(subjectCode==subList[i].getsubjectCode())
            {
                element.second.display();
                cout<<endl<<endl;
                messi = true;
            }
        }
	}

	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}

	system("pause");
	system("CLS");
}

void Lecturer::updateLearningMaterials(map<int,Subject>&subMap)
{
	bool messi = false;
	bool done = false;
	int subjectCode;
	int weekNum;
	string materials;

	viewSubjectList();

    while (true)
    {
        cout<< "Enter Subject code to upload learning materials :";

        try
        {
           subjectCode = getValidatedInput<int>();
        }
        catch (string  e)
        {
           cerr << e << endl;
           continue;
        }

        break;
    }

	for(int k=0; k<assignedSubjects.size(); k++)
	{
		if(subjectCode==assignedSubjects[k].getsubjectCode())
		{
			do
			{

				while (true)
                {
                   cout<<"Enter Week number: ";

                   try
                   {
                      weekNum = getValidatedInput<int>();
                   }
                   catch (string  e)
                   {
                      cerr << e << endl;
                      continue;
                   }

                   break;
                }
                //cin.ignore(10000,'\n');
				cout<<"Upload materials(string): ";
				getline(cin,materials);
				subMap.at(subjectCode).setLearningmaterials(weekNum, materials);
				done =true;
			}while(!done);
			messi = true;
		}
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::updateAttendance(map<int,Student>&stMap, map<int,Subject>&subMap)
{
	bool messi = false;
	vector <Subject> subList;
    int studID;
	int subjectCode;
	double att;


	viewSubjectList();

	while (true)
    {
        cout<< "Enter Subject code to see student list :";

        try
        {
           subjectCode = getValidatedInput<int>();
        }
        catch (string  e)
        {
           cerr << e << endl;
           continue;
        }

        break;
    }

    for(auto element:stMap)
	{
        subList = element.second.getSubjectList();
        for(int i=0; i<subList.size(); i++)
        {
            if(subjectCode==subList[i].getsubjectCode())
            {

                while (true)
                {
                    cout<<"Student Id "<<element.second.getStudentId()<<": ";

                    try
                    {
                        att = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
                studID = element.second.getStudentId();
				subMap.at(subjectCode).setAttendance(studID, att);
				cout<<endl;

                messi = true;
            }
        }
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}

	system("pause");
	system("CLS");
}

void Lecturer::updateTestResult(map<int,Subject>&subMap, map<int,Student>&stMap)
{
	bool messi = false;
	vector <Subject> subList;
	int subjectCode;
	double testScore;
	int studID;
	viewSubjectList();

	while (true)
    {
        cout<< "Enter Subject code to see student list :";

        try
        {
           subjectCode = getValidatedInput<int>();
        }
        catch (string  e)
        {
           cerr << e << endl;
           continue;
        }

        break;
    }

	for(auto element:stMap)
	{
        subList = element.second.getSubjectList();
        for(int i=0; i<subList.size(); i++)
        {
            if(subjectCode==subList[i].getsubjectCode())
            {
				while (true)
                {
                    cout<<"Student Id "<<element.second.getStudentId()<<": ";

                    try
                    {
                        testScore = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
				studID = element.second.getStudentId();
				subMap.at(subjectCode).setTestResult(studID, testScore);
				cout<<endl;

                messi = true;
            }
        }
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::updateCourseWork(map<int,Subject>&subMap, map<int,Student>&stMap)
{
	bool messi = false;
	vector <Subject> subList;
	int subjectCode;
	double courseMark;
	int studID;
	viewSubjectList();

	while (true)
    {
        cout<< "Enter Subject code to see student list :";

        try
        {
           subjectCode = getValidatedInput<int>();
        }
        catch (string  e)
        {
           cerr << e << endl;
           continue;
        }

        break;
    }

	for(auto element:stMap)
	{
        subList = element.second.getSubjectList();
        for(int i=0; i<subList.size(); i++)
        {
            if(subjectCode==subList[i].getsubjectCode())
            {
				while (true)
                {
                    cout<<"Student Id "<<element.second.getStudentId()<<": ";

                    try
                    {
                        courseMark = getValidatedInput<int>();
                    }
                    catch (string  e)
                    {
                        cerr << e << endl;
                        continue;
                    }

                    break;
                }
				studID = element.second.getStudentId();
				subMap.at(subjectCode).setCourseWork(studID, courseMark);
				cout<<endl;

                messi = true;
            }
        }
	}
	if(messi == false)
	{
		cout<< "Not found..."<<endl;
	}
	system("pause");
	system("CLS");
}

void Lecturer::display()
{
	cout<< "Lecturer name = "<<firstName<<" "<<lastName<<endl;
	cout<< "Email = "<<email<<endl;
	cout<< "Contact number = "<<contactNum<<endl;

}

void Lecturer::homeDisplay()
{
	cout<<"Logged in as "<<firstName<<" ID: "<<lecturerId<<endl<<endl;
}

void Lecturer::profileDisplay()
{
	cout<< "First name = "<<firstName<<endl;
	cout<< "Last name = "<<lastName<<endl;
	cout<< "ID = "<<lecturerId<<endl;
	cout<< "Password = "<<password<<endl;
	cout<< "Email = "<<email<<endl;
	cout<< "Address = "<<address<<endl;
	cout<< "Contact number = "<<contactNum<<endl<<endl;
}
